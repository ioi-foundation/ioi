// Path: crates/cli/src/testing/signing_oracle.rs
use anyhow::{anyhow, Result};
use ioi_api::crypto::{SerializableKey, SigningKeyPair};
use ioi_crypto::key_store::encrypt_key; // NEW
use ioi_crypto::sign::eddsa::{Ed25519KeyPair, Ed25519PrivateKey};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::Duration;
use tempfile::TempDir;

const DEFAULT_SIGNER_STARTUP_TIMEOUT: Duration = Duration::from_secs(120);
const SIGNER_STARTUP_POLL_INTERVAL: Duration = Duration::from_millis(100);

/// Manages the lifecycle of a local `ioi-signer` process (the Aft deterministic Signing Oracle) for testing.
pub struct SigningOracleGuard {
    process: std::process::Child,
    pub url: String,
    pub key_path: PathBuf,
    _temp_dir: TempDir, // Keeps state file alive
}

impl SigningOracleGuard {
    pub fn spawn(key_seed: Option<&[u8]>) -> Result<Self> {
        Self::spawn_from_binary_dir(None, key_seed)
    }

    pub fn spawn_from_binary_dir(
        binary_dir: Option<&Path>,
        key_seed: Option<&[u8]>,
    ) -> Result<Self> {
        let temp_dir = tempfile::tempdir()?;
        let state_path = temp_dir.path().join("signer_state.bin");
        let key_path = temp_dir.path().join("signer_key.seed");

        // Default test password
        let password = "test-password";

        let seed_bytes = if let Some(seed) = key_seed {
            seed.to_vec()
        } else {
            let kp = Ed25519KeyPair::generate()?;
            kp.private_key().as_bytes().to_vec()
        };

        // [FIX] Encrypt the key before writing to disk
        let encrypted_key = encrypt_key(&seed_bytes, password)?;
        std::fs::write(&key_path, encrypted_key)?;

        // Pick a random port
        let port = portpicker::pick_unused_port().ok_or(anyhow!("No free ports"))?;
        let addr = format!("127.0.0.1:{}", port);

        let binary_name = if cfg!(windows) {
            "ioi-signer.exe"
        } else {
            "ioi-signer"
        };
        let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let workspace_root = manifest_dir.parent().unwrap().parent().unwrap();
        let mut candidates = Vec::new();
        if let Some(dir) = binary_dir {
            candidates.push(dir.join(binary_name));
        }
        candidates.push(workspace_root.join("target/release").join(binary_name));
        candidates.push(workspace_root.join("target/debug").join(binary_name));

        let binary_path = candidates.iter().find(|path| path.exists()).cloned().ok_or_else(|| {
            anyhow!(
                "ioi-signer binary not found. Searched: {}. Run `cargo build -p ioi-node --bin ioi-signer --features validator-bins` first.",
                candidates
                    .iter()
                    .map(|path| path.display().to_string())
                    .collect::<Vec<_>>()
                    .join(", ")
            )
        })?;

        let mut process = Command::new(binary_path)
            .arg("--state-file")
            .arg(&state_path)
            .arg("--key-file")
            .arg(&key_path)
            .arg("--listen-addr")
            .arg(&addr)
            .env("RUST_LOG", "error")
            // GuardianContainer deliberately refuses password input from a
            // non-TTY stdin. Test signers therefore use the documented
            // non-interactive passphrase channel rather than a pipe that the
            // child can never consume.
            .env("IOI_GUARDIAN_KEY_PASS", password)
            .stdin(Stdio::null())
            .stderr(Stdio::piped())
            .stdout(Stdio::piped())
            .spawn()?;

        // ML-DSA cluster tests can start several encrypted signer processes
        // while the host is still paging freshly linked validator binaries.
        // The release fixture also repeats that work after a four-validator
        // cold restart. Keep a finite, configurable host-resource deadline,
        // but do not confuse a contended debug-binary start with a protocol
        // timeout. The exact release fixture pins this same 120-second bound.
        let startup_timeout = std::env::var("IOI_TEST_SIGNER_STARTUP_TIMEOUT_SECS")
            .ok()
            .and_then(|value| value.parse::<u64>().ok())
            .filter(|value| *value > 0)
            .map(Duration::from_secs)
            .unwrap_or(DEFAULT_SIGNER_STARTUP_TIMEOUT);

        // Wait for the port to be open
        let start = std::time::Instant::now();
        let mut connected = false;
        while start.elapsed() < startup_timeout {
            if let Some(status) = process.try_wait()? {
                let output = process.wait_with_output()?;
                return Err(anyhow!(
                    "ioi-signer exited before readiness with status {status}. stdout: {} stderr: {}",
                    String::from_utf8_lossy(&output.stdout),
                    String::from_utf8_lossy(&output.stderr),
                ));
            }
            if std::net::TcpStream::connect(&addr).is_ok() {
                connected = true;
                break;
            }
            std::thread::sleep(SIGNER_STARTUP_POLL_INTERVAL);
        }

        if !connected {
            // Preserve both streams and the reaped status. A bare timeout hid
            // whether the signer exited, was killed, or was merely slow.
            let kill_error = process.kill().err();
            let output = process.wait_with_output()?;
            return Err(anyhow!(
                "timed out after {:.3}s waiting for ioi-signer; status={}; kill_error={:?}; stdout: {} stderr: {}",
                startup_timeout.as_secs_f64(),
                output.status,
                kill_error,
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr),
            ));
        }

        Ok(Self {
            process,
            url: format!("http://{}", addr),
            key_path,
            _temp_dir: temp_dir,
        })
    }

    pub fn get_keypair(&self) -> Result<libp2p::identity::Keypair> {
        // To return the keypair to the test, we must decrypt what we wrote.
        // In a real test scenario, we know the password ("test-password").
        let encrypted = std::fs::read(&self.key_path)?;
        let decrypted = ioi_crypto::key_store::decrypt_key(&encrypted, "test-password")?;

        let oracle_sk = Ed25519PrivateKey::from_bytes(&decrypted.0)?;
        let oracle_kp = Ed25519KeyPair::from_private_key(&oracle_sk)?;

        let oracle_pk_bytes = oracle_kp.public_key().to_bytes();

        let mut libp2p_bytes = [0u8; 64];
        libp2p_bytes[..32].copy_from_slice(&decrypted.0);
        libp2p_bytes[32..].copy_from_slice(&oracle_pk_bytes);
        Ok(libp2p::identity::Keypair::from(
            libp2p::identity::ed25519::Keypair::try_from_bytes(&mut libp2p_bytes)?,
        ))
    }
}

impl Drop for SigningOracleGuard {
    fn drop(&mut self) {
        let _ = self.process.kill();
        let _ = self.process.wait();
    }
}
