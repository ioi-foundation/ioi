use async_trait::async_trait;
use ioi_api::vm::drivers::gui::{GuiDriver, InputEvent};
use ioi_api::vm::inference::mock::MockInferenceRuntime;
use ioi_drivers::browser::BrowserDriver;
use ioi_drivers::mcp::McpManager;
use ioi_drivers::os::UnavailableOsDriver;
use ioi_drivers::terminal::TerminalDriver;
use ioi_services::agentic::runtime::execution::ToolExecutor;
use ioi_services::agentic::runtime::service::recovery::anti_loop::{
    build_post_state_summary, build_state_summary, policy_binding_hash,
};
use ioi_services::agentic::runtime::service::tool_execution::{
    canonical_intent_hash, canonical_tool_identity,
};
use ioi_services::agentic::runtime::types::{ExecutionTier, InteractionTarget};
use ioi_services::agentic::runtime::{AgentMode, AgentState, AgentStatus};
use ioi_types::app::agentic::{AgentTool, ScreenAction};
use ioi_types::app::{ActionRequest, ActionTarget, ContextSlice, RoutingReceiptEvent};
use ioi_types::error::VmError;
use std::collections::BTreeMap;
use std::sync::{Arc, Mutex};

#[derive(Default)]
struct MockGuiDriver {
    events: Mutex<Vec<InputEvent>>,
}

impl MockGuiDriver {
    fn take_events(&self) -> Vec<InputEvent> {
        let mut guard = self.events.lock().expect("events mutex poisoned");
        std::mem::take(&mut *guard)
    }
}

#[async_trait]
impl GuiDriver for MockGuiDriver {
    async fn capture_screen(
        &self,
        _crop_rect: Option<(i32, i32, u32, u32)>,
    ) -> Result<Vec<u8>, VmError> {
        Ok(Vec::new())
    }

    async fn capture_raw_screen(&self) -> Result<Vec<u8>, VmError> {
        Ok(Vec::new())
    }

    async fn capture_tree(&self) -> Result<String, VmError> {
        Ok(String::new())
    }

    async fn capture_context(&self, _intent: &ActionRequest) -> Result<ContextSlice, VmError> {
        Err(VmError::HostError(
            "capture_context is not used in this test".to_string(),
        ))
    }

    async fn inject_input(&self, event: InputEvent) -> Result<(), VmError> {
        let mut guard = self.events.lock().expect("events mutex poisoned");
        guard.push(event);
        Ok(())
    }

    async fn get_element_center(&self, _id: u32) -> Result<Option<(u32, u32)>, VmError> {
        Ok(None)
    }

    async fn get_cursor_position(&self) -> Result<(u32, u32), VmError> {
        Ok((0, 0))
    }
}

fn build_executor(gui: Arc<MockGuiDriver>) -> ToolExecutor {
    let gui_driver: Arc<dyn GuiDriver> = gui;
    ToolExecutor::new(
        gui_driver,
        Arc::new(UnavailableOsDriver::default()),
        Arc::new(TerminalDriver::new()),
        Arc::new(BrowserDriver::new()),
        Arc::new(McpManager::new()),
        None,
        None,
        Arc::new(MockInferenceRuntime::default()),
        None,
    )
    .with_window_context(None, None, Some(ExecutionTier::VisualForeground))
}

fn test_agent_state() -> AgentState {
    AgentState {
        session_id: [0x77; 32],
        goal: "scroll a pane".to_string(),
        transcript_root: [0u8; 32],
        status: AgentStatus::Running,
        step_count: 9,
        max_steps: 32,
        last_action_type: None,
        parent_session_id: None,
        child_session_ids: vec![],
        budget: 16,
        tokens_used: 0,
        consecutive_failures: 0,
        pending_approval: None,
        pending_tool_call: None,
        pending_tool_jcs: None,
        pending_tool_hash: None,
        pending_request_nonce: None,
        pending_visual_hash: None,
        recent_actions: vec![],
        mode: AgentMode::Agent,
        current_tier: ExecutionTier::VisualForeground,
        last_screen_phash: None,
        execution_queue: vec![],
        active_skill_hash: None,
        tool_execution_log: BTreeMap::new(),
        execution_ledger: Default::default(),
        visual_som_map: None,
        visual_semantic_map: None,
        runtime_route_frame: None,
        work_graph_context: None,
        target: Some(InteractionTarget {
            app_hint: Some("spreadsheet".to_string()),
            title_pattern: None,
        }),
        resolved_intent: None,

        awaiting_intent_clarification: false,

        working_directory: ".".to_string(),
        command_history: Default::default(),
        active_lens: None,
        pending_search_completion: None,
        planner_state: None,
    }
}

#[test]
fn scroll_tool_types_and_target_mapping() {
    let tool = AgentTool::GuiScroll {
        delta_x: 0,
        delta_y: 10,
    };
    assert_eq!(tool.target(), ActionTarget::GuiScroll);

    let computer_scroll = AgentTool::Screen(ScreenAction::Scroll {
        coordinate: Some([100, 100]),
        delta: [0, -5],
    });
    assert_eq!(computer_scroll.target(), ActionTarget::GuiScroll);
}

#[tokio::test]
async fn gui_scroll_dispatch_preserves_horizontal_and_vertical_delta() {
    let gui = Arc::new(MockGuiDriver::default());
    let exec = build_executor(gui.clone());

    let result = exec
        .execute(
            AgentTool::GuiScroll {
                delta_x: 37,
                delta_y: -120,
            },
            [0u8; 32],
            1,
            [0u8; 32],
            None,
            None,
            None,
        )
        .await;

    assert!(result.success, "{:?}", result.error);
    assert_eq!(
        gui.take_events(),
        vec![InputEvent::Scroll { dx: 37, dy: -120 }]
    );
}

#[tokio::test]
async fn computer_scroll_dispatch_preserves_delta_axis_order() {
    let gui = Arc::new(MockGuiDriver::default());
    let exec = build_executor(gui.clone());

    let result = exec
        .execute(
            AgentTool::Screen(ScreenAction::Scroll {
                coordinate: None,
                delta: [11, 240],
            }),
            [0u8; 32],
            2,
            [0u8; 32],
            None,
            None,
            None,
        )
        .await;

    assert!(result.success, "{:?}", result.error);
    assert_eq!(
        gui.take_events(),
        vec![InputEvent::Scroll { dx: 11, dy: 240 }]
    );
}

#[test]
fn routing_receipt_contract_for_scroll_includes_canonical_hash_and_pre_state() {
    let state = test_agent_state();
    let tool = AgentTool::GuiScroll {
        delta_x: 64,
        delta_y: -240,
    };

    let (tool_name, args) = canonical_tool_identity(&tool);
    assert_eq!(tool_name, "screen__scroll");
    assert_eq!(args.get("delta_x").and_then(|v| v.as_i64()), Some(64));
    assert_eq!(args.get("delta_y").and_then(|v| v.as_i64()), Some(-240));

    let intent_hash = canonical_intent_hash(
        &tool_name,
        &args,
        ExecutionTier::VisualForeground,
        state.step_count,
        "test-v1",
    );
    assert!(!intent_hash.is_empty());

    let pre_state = build_state_summary(&state);
    let verification_checks = vec![
        "policy_decision=allowed".to_string(),
        "scroll_dispatch=dx_dy".to_string(),
    ];
    let post_state = build_post_state_summary(&state, true, verification_checks.clone());
    let binding_hash = policy_binding_hash(&intent_hash, "allowed");

    let receipt = RoutingReceiptEvent {
        session_id: state.session_id,
        step_index: pre_state.step_index,
        intent_hash: intent_hash.clone(),
        policy_decision: "allowed".to_string(),
        tool_name,
        tool_version: "test-v1".to_string(),
        pre_state: pre_state.clone(),
        action_json: serde_json::to_string(&tool).unwrap(),
        post_state,
        artifacts: vec!["trace://agent_step/9".to_string()],
        failure_class: None,
        failure_class_name: String::new(),
        intent_class: String::new(),
        incident_id: String::new(),
        incident_stage: String::new(),
        strategy_name: String::new(),
        strategy_node: String::new(),
        gate_state: String::new(),
        resolution_action: String::new(),
        stop_condition_hit: false,
        escalation_path: None,
        lineage_ptr: None,
        mutation_receipt_ptr: None,
        policy_binding_hash: binding_hash.clone(),
        policy_binding_sig: None,
        policy_binding_signer: None,
        route_decision: Default::default(),
    };

    assert_eq!(receipt.intent_hash, intent_hash);
    assert_eq!(receipt.pre_state.agent_status, "Running");
    assert_eq!(receipt.pre_state.tier, "VisualLast");
    assert_eq!(receipt.pre_state.step_index, 9);
    assert_eq!(
        receipt.pre_state.target_hint.as_deref(),
        Some("spreadsheet")
    );
    assert_eq!(receipt.post_state.verification_checks, verification_checks);
    assert_eq!(receipt.policy_binding_hash, binding_hash);
}
