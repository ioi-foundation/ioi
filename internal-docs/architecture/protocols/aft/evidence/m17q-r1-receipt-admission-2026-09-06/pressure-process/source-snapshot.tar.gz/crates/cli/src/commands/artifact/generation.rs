use super::evidence::build_artifact_lane_receipts;
use super::*;
use ioi_api::chat::{
    compile_chat_artifact_ir, derive_chat_artifact_blueprint,
    derive_request_grounded_chat_artifact_brief,
    generate_chat_artifact_bundle_with_runtimes_and_planning_context_and_render_evaluator,
    ChatArtifactPlanningContext, ChatArtifactRuntimePolicyProfile, ChatArtifactSelectionTarget,
};
use ioi_drivers::chat_render::BrowserChatArtifactRenderEvaluator;
use std::env;

pub(super) async fn run_route(
    prompt: &str,
    active_artifact_id: Option<&str>,
    refinement_path: Option<&Path>,
    selected_target_json: &[String],
    fixture_path: Option<&Path>,
    use_local_runtime: bool,
    use_mock_runtime: bool,
    api_url: Option<&str>,
    api_key: Option<&str>,
    model_name: Option<&str>,
    json_output: bool,
) -> Result<()> {
    let runtime = build_inference_runtime(
        fixture_path,
        use_local_runtime,
        use_mock_runtime,
        api_url,
        api_key,
        model_name,
    )?;
    let provenance = runtime.chat_runtime_provenance();
    let selected_targets = parse_selected_targets(selected_target_json)?;
    let (_, refinement_context) =
        load_selected_refinement(refinement_path, selected_targets.as_slice())?;
    let route = match route_with_runtime(
        runtime,
        prompt,
        active_artifact_id,
        refinement_context.as_ref(),
    )
    .await
    {
        Ok(route) => route,
        Err(error) => {
            emit_json_failure(
                json_output,
                ChatArtifactFailure {
                    kind: ChatArtifactFailureKind::RoutingFailure,
                    code: if matches!(
                        provenance.kind,
                        ChatRuntimeProvenanceKind::InferenceUnavailable
                    ) {
                        "inference_unavailable"
                    } else {
                        "routing_failure"
                    }
                    .to_string(),
                    message: error.to_string(),
                },
                Some(provenance),
                None,
            )?;
            return Err(error);
        }
    };

    if json_output {
        println!("{}", serde_json::to_string_pretty(&route)?);
        return Ok(());
    }

    println!("Route: {}", outcome_kind_label(&route));
    println!("  confidence: {:.2}", route.confidence);
    println!(
        "  clarification: {}",
        if route.needs_clarification {
            "yes"
        } else {
            "no"
        }
    );
    if let Some(artifact) = &route.artifact {
        println!(
            "  artifact class: {}",
            artifact_class_label(artifact.artifact_class)
        );
        println!("  renderer: {}", renderer_label(artifact.renderer));
    }
    if !route.clarification_questions.is_empty() {
        for question in &route.clarification_questions {
            println!("  - {}", question);
        }
    }
    Ok(())
}

#[cfg(test)]
pub(super) async fn route_with_runtime(
    runtime: Arc<dyn InferenceRuntime>,
    prompt: &str,
    active_artifact_id: Option<&str>,
    active_artifact: Option<&ChatArtifactRefinementContext>,
) -> Result<ChatOutcomePlanningPayload> {
    plan_chat_outcome_with_runtime(runtime, prompt, active_artifact_id, active_artifact)
        .await
        .map_err(|error| {
            anyhow::anyhow!("Failed to route Chat prompt through local inference: {error}")
        })
}

#[cfg(not(test))]
async fn route_with_runtime(
    runtime: Arc<dyn InferenceRuntime>,
    prompt: &str,
    active_artifact_id: Option<&str>,
    active_artifact: Option<&ChatArtifactRefinementContext>,
) -> Result<ChatOutcomePlanningPayload> {
    plan_chat_outcome_with_runtime(runtime, prompt, active_artifact_id, active_artifact)
        .await
        .map_err(|error| {
            anyhow::anyhow!("Failed to route Chat prompt through local inference: {error}")
        })
}

pub(super) fn select_generate_route_runtime(
    production_runtime: &Arc<dyn InferenceRuntime>,
    acceptance_runtime: &Arc<dyn InferenceRuntime>,
) -> Arc<dyn InferenceRuntime> {
    let production_provenance = production_runtime.chat_runtime_provenance();
    let acceptance_provenance = acceptance_runtime.chat_runtime_provenance();
    if production_provenance.kind == ChatRuntimeProvenanceKind::RealLocalRuntime
        && acceptance_provenance.kind == ChatRuntimeProvenanceKind::RealLocalRuntime
        && !runtime_provenance_matches(&production_provenance, &acceptance_provenance)
    {
        return acceptance_runtime.clone();
    }
    production_runtime.clone()
}

pub(super) fn parse_selected_targets(
    selected_target_json: &[String],
) -> Result<Vec<ChatArtifactSelectionTarget>> {
    selected_target_json
        .iter()
        .enumerate()
        .map(|(index, raw)| {
            serde_json::from_str::<ChatArtifactSelectionTarget>(raw).with_context(|| {
                format!(
                    "Failed to parse --selected-target-json value {} as a ChatArtifactSelectionTarget.",
                    index + 1
                )
            })
        })
        .collect()
}

pub(super) fn apply_selected_targets_to_loaded_refinement(
    refinement: &mut Option<super::types::LoadedRefinementEvidence>,
    selected_targets: &[ChatArtifactSelectionTarget],
) -> Result<()> {
    if selected_targets.is_empty() {
        return Ok(());
    }

    let Some(loaded) = refinement.as_mut() else {
        return Err(anyhow::anyhow!(
            "--selected-target-json requires --refinement so the selection can be grounded in an active artifact."
        ));
    };
    loaded.selected_targets = selected_targets.to_vec();
    Ok(())
}

fn load_selected_refinement(
    refinement_path: Option<&Path>,
    selected_targets: &[ChatArtifactSelectionTarget],
) -> Result<(
    Option<super::types::LoadedRefinementEvidence>,
    Option<ChatArtifactRefinementContext>,
)> {
    let mut refinement = load_refinement_evidence(refinement_path)?;
    apply_selected_targets_to_loaded_refinement(&mut refinement, selected_targets)?;
    let refinement_context = refinement
        .as_ref()
        .map(refinement_context_from_loaded_evidence);
    Ok((refinement, refinement_context))
}

fn refinement_context_from_loaded_evidence(
    loaded: &super::types::LoadedRefinementEvidence,
) -> ChatArtifactRefinementContext {
    ChatArtifactRefinementContext {
        artifact_id: loaded.artifact_id.clone(),
        revision_id: loaded.revision_id.clone(),
        title: loaded.title.clone(),
        summary: loaded.summary.clone(),
        renderer: loaded.renderer,
        files: loaded.files.clone(),
        selected_targets: loaded.selected_targets.clone(),
        taste_memory: loaded.taste_memory.clone(),
        retrieved_exemplars: Vec::new(),
        blueprint: None,
        artifact_ir: None,
        selected_skills: Vec::new(),
    }
}

fn configured_runtime_profile() -> ChatArtifactRuntimePolicyProfile {
    [
        "HYPERVISOR_CHAT_ARTIFACT_MODEL_ROUTING_PROFILE",
        "IOI_CHAT_ARTIFACT_MODEL_ROUTING_PROFILE",
    ]
    .iter()
    .find_map(|key| {
        env::var(key)
            .ok()
            .as_deref()
            .and_then(ChatArtifactRuntimePolicyProfile::parse)
    })
    .unwrap_or(ChatArtifactRuntimePolicyProfile::Auto)
}

pub(super) async fn run_generate(
    prompt: &str,
    output: &Path,
    force: bool,
    active_artifact_id: Option<&str>,
    refinement_path: Option<&Path>,
    selected_target_json: &[String],
    fixture_path: Option<&Path>,
    use_local_runtime: bool,
    use_mock_runtime: bool,
    api_url: Option<&str>,
    api_key: Option<&str>,
    model_name: Option<&str>,
    acceptance_api_url: Option<&str>,
    acceptance_api_key: Option<&str>,
    acceptance_model_name: Option<&str>,
    json_output: bool,
) -> Result<()> {
    let runtime = build_inference_runtime(
        fixture_path,
        use_local_runtime,
        use_mock_runtime,
        api_url,
        api_key,
        model_name,
    )?;
    let provenance = runtime.chat_runtime_provenance();
    let acceptance_runtime = build_acceptance_inference_runtime(
        runtime.clone(),
        fixture_path,
        use_mock_runtime,
        acceptance_api_url,
        acceptance_api_key,
        acceptance_model_name,
    )?;
    let acceptance_provenance = acceptance_runtime.chat_runtime_provenance();
    let route_runtime = select_generate_route_runtime(&runtime, &acceptance_runtime);
    let selected_targets = parse_selected_targets(selected_target_json)?;
    let (refinement, refinement_context) =
        load_selected_refinement(refinement_path, selected_targets.as_slice())?;
    let route = match route_with_runtime(
        route_runtime,
        prompt,
        active_artifact_id,
        refinement_context.as_ref(),
    )
    .await
    {
        Ok(route) => route,
        Err(error) => {
            emit_json_failure(
                json_output,
                ChatArtifactFailure {
                    kind: ioi_types::app::ChatArtifactFailureKind::RoutingFailure,
                    code: if matches!(
                        provenance.kind,
                        ioi_types::app::ChatRuntimeProvenanceKind::InferenceUnavailable
                    ) {
                        "inference_unavailable"
                    } else {
                        "routing_failure"
                    }
                    .to_string(),
                    message: error.to_string(),
                },
                Some(provenance),
                None,
            )?;
            return Err(error);
        }
    };
    let request = route
        .artifact
        .clone()
        .ok_or_else(|| anyhow::anyhow!("Chat route did not produce an artifact request."))?;
    let title = derive_generated_artifact_title(prompt);
    let bundle: Result<_, anyhow::Error> =
        if request.renderer == ChatRendererKind::WorkspaceSurface {
            generate_workspace_artifact_bundle_with_runtimes(
                runtime,
                acceptance_runtime,
                &title,
                prompt,
                &request,
                refinement_context.as_ref(),
            )
            .await
            .map_err(anyhow::Error::msg)
        } else {
            let render_evaluator = BrowserChatArtifactRenderEvaluator::default();
            let brief = derive_request_grounded_chat_artifact_brief(
                &title,
                prompt,
                &request,
                refinement_context.as_ref(),
            );
            let blueprint = derive_chat_artifact_blueprint(&request, &brief);
            let artifact_ir = compile_chat_artifact_ir(&request, &brief, &blueprint);
            let planning_context = ChatArtifactPlanningContext {
                brief,
                blueprint: Some(blueprint),
                artifact_ir: Some(artifact_ir),
                preparation_needs: None,
                prepared_context_resolution: None,
                skill_discovery_resolution: None,
                selected_skills: Vec::new(),
                retrieved_exemplars: Vec::new(),
                retrieved_sources: Vec::new(),
            };
            generate_chat_artifact_bundle_with_runtimes_and_planning_context_and_render_evaluator(
                runtime,
                Some(acceptance_runtime),
                configured_runtime_profile(),
                &title,
                prompt,
                &request,
                refinement_context.as_ref(),
                &planning_context,
                Some(&render_evaluator),
            )
            .await
            .map_err(anyhow::Error::new)
        }
        .map_err(|error| anyhow::anyhow!("Failed to generate Chat artifact bundle: {error}"));
    let bundle = match bundle {
        Ok(bundle) => bundle,
        Err(error) => {
            emit_json_failure(
                json_output,
                ChatArtifactFailure {
                    kind: ChatArtifactFailureKind::GenerationFailure,
                    code: if matches!(
                        provenance.kind,
                        ChatRuntimeProvenanceKind::InferenceUnavailable
                    ) || matches!(
                        acceptance_provenance.kind,
                        ChatRuntimeProvenanceKind::InferenceUnavailable
                    ) {
                        "inference_unavailable"
                    } else {
                        "generation_failure"
                    }
                    .to_string(),
                    message: error.to_string(),
                },
                Some(provenance),
                Some(acceptance_provenance),
            )?;
            return Err(error);
        }
    };

    prepare_output_directory(output, force)?;
    write_generated_payload(output, &title, &bundle.winner)?;

    let manifest = build_generated_manifest(
        &title,
        &request,
        &bundle.winner,
        &bundle.validation,
        &bundle.production_provenance,
        &bundle.acceptance_provenance,
        bundle.failure.as_ref(),
    );
    let manifest_path = output.join("artifact-manifest.json");
    fs::write(
        &manifest_path,
        serde_json::to_vec_pretty(&manifest).context("Failed to serialize generated manifest.")?,
    )
    .with_context(|| format!("Failed to write '{}'.", manifest_path.display()))?;
    let verified_reply = compose_verified_reply(&manifest);
    let artifact_lane_receipts = build_artifact_lane_receipts(
        bundle.blueprint.as_ref(),
        bundle.selected_skills.as_slice(),
        bundle.candidate_summaries.as_slice(),
        &bundle.validation,
        bundle.ux_lifecycle,
    );
    let evidence = GeneratedArtifactEvidence {
        prompt: prompt.to_string(),
        title: title.clone(),
        route,
        artifact_brief: Some(bundle.brief),
        blueprint: bundle.blueprint,
        artifact_ir: bundle.artifact_ir,
        selected_skills: bundle.selected_skills,
        edit_intent: bundle.edit_intent,
        candidate_summaries: bundle.candidate_summaries,
        winning_candidate_id: bundle.winning_candidate_id,
        winning_candidate_rationale: bundle.winning_candidate_rationale,
        render_evaluation: bundle.render_evaluation,
        validation: Some(bundle.validation),
        output_origin: Some(bundle.origin),
        runtime_policy: bundle.runtime_policy,
        adaptive_search_budget: bundle.adaptive_search_budget,
        artifact_lane_receipts,
        production_provenance: Some(bundle.production_provenance),
        acceptance_provenance: Some(bundle.acceptance_provenance),
        degraded_path_used: bundle.degraded_path_used,
        ux_lifecycle: Some(bundle.ux_lifecycle),
        failure: bundle.failure,
        manifest,
        verified_reply,
        materialized_files: bundle
            .winner
            .files
            .iter()
            .map(|file| file.path.clone())
            .collect(),
        renderable_files: bundle
            .winner
            .files
            .iter()
            .filter(|file| file.renderable)
            .map(|file| file.path.clone())
            .collect(),
        refinement,
    };
    let evidence_path = output.join("generation.json");
    fs::write(
        &evidence_path,
        serde_json::to_vec_pretty(&evidence).context("Failed to serialize generation evidence.")?,
    )
    .with_context(|| format!("Failed to write '{}'.", evidence_path.display()))?;

    if json_output {
        println!("{}", serde_json::to_string_pretty(&evidence)?);
        return Ok(());
    }

    println!("Generated: {}", evidence.title);
    println!("  renderer: {}", renderer_label(request.renderer));
    let validation_label = evidence
        .validation
        .as_ref()
        .map(format_validation_label)
        .unwrap_or("unavailable");
    println!("  validation: {}", validation_label);
    println!("  output: {}", output.display());
    println!("  evidence: {}", evidence_path.display());
    Ok(())
}

fn emit_json_failure(
    json_output: bool,
    error: ChatArtifactFailure,
    production_provenance: Option<ChatRuntimeProvenance>,
    acceptance_provenance: Option<ChatRuntimeProvenance>,
) -> Result<()> {
    if json_output {
        println!(
            "{}",
            serde_json::to_string_pretty(&ArtifactCommandErrorEnvelope {
                error,
                production_provenance,
                acceptance_provenance,
            })?
        );
    }
    Ok(())
}
