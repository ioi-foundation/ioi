use super::model_mount_http::{daemon_request, print_value};
use anyhow::Result;
use clap::{Parser, Subcommand};
use reqwest::Method;
use serde_json::json;

#[derive(Parser, Debug)]
pub struct ModelsArgs {
    /// Runtime daemon endpoint. Defaults to IOI_DAEMON_ENDPOINT or http://127.0.0.1:8765.
    #[clap(long)]
    pub endpoint: Option<String>,

    /// Capability token. Defaults to IOI_DAEMON_TOKEN.
    #[clap(long)]
    pub token: Option<String>,

    /// Emit machine-readable JSON.
    #[clap(long)]
    pub json: bool,

    #[clap(subcommand)]
    pub command: ModelsCommands,
}

#[derive(Subcommand, Debug)]
pub enum ModelsCommands {
    /// List registry artifacts, endpoints, instances, providers, routes, and receipts.
    Ls,
    /// List canonical model capability readiness contracts.
    Capabilities,
    /// Inspect one model artifact by artifact id or model id.
    Get { id: String },
    /// Search the model catalog through deterministic fixtures or gated live adapters.
    CatalogSearch {
        #[clap(long, default_value = "hypervisor")]
        query: String,
        #[clap(long)]
        format: Option<String>,
        #[clap(long)]
        quantization: Option<String>,
        #[clap(long)]
        limit: Option<u64>,
    },
    /// Import or download a model from a catalog/source URL.
    CatalogImportUrl {
        source_url: String,
        #[clap(long)]
        model_id: Option<String>,
        #[clap(long)]
        provider_id: Option<String>,
    },
    /// Import a model artifact into the registry.
    Import {
        model_id: String,
        #[clap(long)]
        provider_id: Option<String>,
        #[clap(long)]
        path: Option<String>,
        #[clap(long)]
        import_mode: Option<String>,
    },
    /// Create a model download job through the daemon lifecycle path.
    Download {
        model_id: String,
        #[clap(long)]
        provider_id: Option<String>,
        #[clap(long)]
        source_url: Option<String>,
        #[clap(long)]
        queued_only: bool,
    },
    /// Cancel a queued or running model download job.
    CancelDownload { job_id: String },
    /// Delete an installed model artifact and record cleanup state.
    Delete { id: String },
    /// Scan model storage for orphan artifacts and record a cleanup receipt.
    Cleanup,
    /// Mount a model endpoint.
    Mount {
        model_id: String,
        #[clap(long)]
        id: Option<String>,
        #[clap(long)]
        provider_id: Option<String>,
    },
    /// Load a mounted endpoint or model id.
    Load {
        #[clap(long)]
        endpoint_id: Option<String>,
        #[clap(long)]
        model_id: Option<String>,
        #[clap(long, default_value = "on_demand")]
        mode: String,
        #[clap(long, default_value_t = 900)]
        idle_ttl_seconds: u64,
        #[clap(long)]
        estimate_only: bool,
        #[clap(long)]
        gpu: Option<String>,
        #[clap(long)]
        context_length: Option<u64>,
        #[clap(long)]
        parallel: Option<u64>,
        #[clap(long)]
        ttl_seconds: Option<u64>,
        #[clap(long)]
        identifier: Option<String>,
    },
    /// Unload a model instance or endpoint.
    Unload {
        #[clap(long)]
        instance_id: Option<String>,
        #[clap(long)]
        endpoint_id: Option<String>,
        #[clap(long)]
        model_id: Option<String>,
    },
    /// List loaded model instances.
    Ps,
    /// List models discovered by a provider driver.
    ProviderModels { provider_id: String },
    /// List loaded models observed by a provider driver.
    ProviderLoaded { provider_id: String },
    /// Tokenize text through the selected model route or deterministic estimator.
    Tokenize {
        #[clap(long)]
        model: Option<String>,
        #[clap(long)]
        route_id: Option<String>,
        input: String,
    },
    /// Fit text into a model context window.
    ContextFit {
        #[clap(long)]
        model: Option<String>,
        #[clap(long)]
        route_id: Option<String>,
        #[clap(long)]
        context_length: Option<u64>,
        #[clap(long)]
        max_output_tokens: Option<u64>,
        input: String,
    },
    /// Probe provider health or inspect the latest provider health receipt.
    ProviderHealth {
        provider_id: String,
        #[clap(long)]
        latest: bool,
    },
    /// Create or update a provider profile.
    ProviderSet {
        #[clap(long)]
        id: String,
        #[clap(long)]
        kind: String,
        #[clap(long)]
        label: Option<String>,
        #[clap(long)]
        api_format: Option<String>,
        #[clap(long)]
        base_url: Option<String>,
        #[clap(long)]
        status: Option<String>,
        #[clap(long)]
        privacy_class: Option<String>,
        #[clap(long, value_delimiter = ',')]
        capabilities: Vec<String>,
        /// Wallet vault reference for provider auth material. Raw keys are rejected by the daemon.
        #[clap(long)]
        secret_ref: Option<String>,
        /// Provider auth scheme: bearer, api_key, or raw.
        #[clap(long)]
        auth_scheme: Option<String>,
        /// Provider auth header name, such as authorization or x-api-key.
        #[clap(long)]
        auth_header_name: Option<String>,
    },
}

pub async fn run(args: ModelsArgs) -> Result<()> {
    let endpoint = args.endpoint.as_deref();
    let token = args.token.as_deref();
    let value = match args.command {
        ModelsCommands::Ls => {
            daemon_request(endpoint, token, Method::GET, "/v1/models", None).await?
        }
        ModelsCommands::Capabilities => {
            daemon_request(endpoint, token, Method::GET, "/v1/model-capabilities", None).await?
        }
        ModelsCommands::Get { id } => {
            daemon_request(
                endpoint,
                token,
                Method::GET,
                &format!("/v1/models/{id}"),
                None,
            )
            .await?
        }
        ModelsCommands::CatalogSearch {
            query,
            format,
            quantization,
            limit,
        } => {
            let mut params = vec![format!("query={}", query.replace(' ', "%20"))];
            if let Some(format) = format {
                params.push(format!("format={}", format.replace(' ', "%20")));
            }
            if let Some(quantization) = quantization {
                params.push(format!("quantization={}", quantization.replace(' ', "%20")));
            }
            if let Some(limit) = limit {
                params.push(format!("limit={limit}"));
            }
            daemon_request(
                endpoint,
                token,
                Method::GET,
                &format!("/v1/models/catalog/search?{}", params.join("&")),
                None,
            )
            .await?
        }
        ModelsCommands::CatalogImportUrl {
            source_url,
            model_id,
            provider_id,
        } => {
            daemon_request(
                endpoint,
                token,
                Method::POST,
                "/v1/model-mount/catalog/import-url",
                Some(json!({
                    "source_url": source_url,
                    "model_id": model_id,
                    "provider_id": provider_id
                })),
            )
            .await?
        }
        ModelsCommands::Import {
            model_id,
            provider_id,
            path,
            import_mode,
        } => {
            daemon_request(
                endpoint,
                token,
                Method::POST,
                "/v1/model-mount/artifacts/import",
                Some(json!({
                    "model_id": model_id,
                    "provider_id": provider_id,
                    "path": path,
                    "import_mode": import_mode
                })),
            )
            .await?
        }
        ModelsCommands::Download {
            model_id,
            provider_id,
            source_url,
            queued_only,
        } => {
            daemon_request(
                endpoint,
                token,
                Method::POST,
                "/v1/model-mount/downloads",
                Some(json!({
                    "model_id": model_id,
                    "provider_id": provider_id,
                    "source_url": source_url,
                    "queued_only": queued_only
                })),
            )
            .await?
        }
        ModelsCommands::CancelDownload { job_id } => {
            daemon_request(
                endpoint,
                token,
                Method::POST,
                &format!("/v1/model-mount/downloads/{job_id}/cancel"),
                None,
            )
            .await?
        }
        ModelsCommands::Delete { id } => {
            daemon_request(
                endpoint,
                token,
                Method::DELETE,
                &format!("/v1/model-mount/artifacts/{id}"),
                None,
            )
            .await?
        }
        ModelsCommands::Cleanup => {
            daemon_request(
                endpoint,
                token,
                Method::POST,
                "/v1/model-mount/storage/cleanup",
                None,
            )
            .await?
        }
        ModelsCommands::Mount {
            model_id,
            id,
            provider_id,
        } => {
            daemon_request(
                endpoint,
                token,
                Method::POST,
                "/v1/model-mount/endpoints",
                Some(json!({ "id": id, "model_id": model_id, "provider_id": provider_id })),
            )
            .await?
        }
        ModelsCommands::Load {
            endpoint_id,
            model_id,
            mode,
            idle_ttl_seconds,
            estimate_only,
            gpu,
            context_length,
            parallel,
            ttl_seconds,
            identifier,
        } => {
            let ttl = ttl_seconds.unwrap_or(idle_ttl_seconds);
            daemon_request(
                endpoint,
                token,
                Method::POST,
                "/v1/model-mount/instances/load",
                Some(json!({
                    "endpoint_id": endpoint_id,
                    "model_id": model_id,
                    "load_policy": {
                        "mode": mode,
                        "idle_ttl_seconds": ttl,
                        "auto_evict": true
                    },
                    "load_options": {
                        "estimate_only": estimate_only,
                        "gpu": gpu,
                        "context_length": context_length,
                        "parallel": parallel,
                        "ttl_seconds": ttl,
                        "identifier": identifier
                    }
                })),
            )
            .await?
        }
        ModelsCommands::Unload {
            instance_id,
            endpoint_id,
            model_id,
        } => {
            daemon_request(
                endpoint,
                token,
                Method::POST,
                "/v1/model-mount/instances/unload",
                Some(json!({
                    "instance_id": instance_id,
                    "endpoint_id": endpoint_id,
                    "model_id": model_id
                })),
            )
            .await?
        }
        ModelsCommands::Ps => {
            daemon_request(
                endpoint,
                token,
                Method::GET,
                "/v1/model-mount/instances/loaded",
                None,
            )
            .await?
        }
        ModelsCommands::ProviderModels { provider_id } => {
            daemon_request(
                endpoint,
                token,
                Method::GET,
                &format!("/v1/model-mount/providers/{provider_id}/models"),
                None,
            )
            .await?
        }
        ModelsCommands::ProviderLoaded { provider_id } => {
            daemon_request(
                endpoint,
                token,
                Method::GET,
                &format!("/v1/model-mount/providers/{provider_id}/loaded"),
                None,
            )
            .await?
        }
        ModelsCommands::Tokenize {
            model,
            route_id,
            input,
        } => {
            daemon_request(
                endpoint,
                token,
                Method::POST,
                "/v1/model-mount/tokens/tokenize",
                Some(json!({
                    "model": model,
                    "route_id": route_id,
                    "input": input
                })),
            )
            .await?
        }
        ModelsCommands::ContextFit {
            model,
            route_id,
            context_length,
            max_output_tokens,
            input,
        } => {
            daemon_request(
                endpoint,
                token,
                Method::POST,
                "/v1/model-mount/context/fit",
                Some(json!({
                    "model": model,
                    "route_id": route_id,
                    "context_length": context_length,
                    "max_output_tokens": max_output_tokens,
                    "input": input
                })),
            )
            .await?
        }
        ModelsCommands::ProviderHealth {
            provider_id,
            latest,
        } => {
            if latest {
                daemon_request(
                    endpoint,
                    token,
                    Method::GET,
                    &format!("/v1/model-mount/providers/{provider_id}/health/latest"),
                    None,
                )
                .await?
            } else {
                daemon_request(
                    endpoint,
                    token,
                    Method::POST,
                    &format!("/v1/model-mount/providers/{provider_id}/health"),
                    None,
                )
                .await?
            }
        }
        ModelsCommands::ProviderSet {
            id,
            kind,
            label,
            api_format,
            base_url,
            status,
            privacy_class,
            capabilities,
            secret_ref,
            auth_scheme,
            auth_header_name,
        } => {
            daemon_request(
                endpoint,
                token,
                Method::POST,
                "/v1/model-mount/providers",
                Some(json!({
                    "id": id,
                    "kind": kind,
                    "label": label,
                    "api_format": api_format,
                    "base_url": base_url,
                    "status": status,
                    "privacy_class": privacy_class,
                    "capabilities": capabilities,
                    "secret_ref": secret_ref,
                    "auth_scheme": auth_scheme,
                    "auth_header_name": auth_header_name
                })),
            )
            .await?
        }
    };
    print_value(&value, args.json)
}
