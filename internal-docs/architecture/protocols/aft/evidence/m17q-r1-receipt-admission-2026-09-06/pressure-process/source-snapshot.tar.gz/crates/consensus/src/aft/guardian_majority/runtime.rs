use super::*;

impl ConsensusControl for GuardianMajorityEngine {
    fn experimental_sample_tip(&self) -> Option<([u8; 32], u32)> {
        None
    }

    fn observe_experimental_sample(&mut self, _hash: [u8; 32]) {}
}

#[async_trait]
impl PenaltyMechanism for GuardianMajorityEngine {
    async fn apply_penalty(
        &self,
        state: &mut dyn StateAccess,
        report: &FailureReport,
    ) -> Result<(), TransactionError> {
        apply_quarantine_penalty(state, report).await
    }
}

impl PenaltyEngine for GuardianMajorityEngine {
    fn apply(
        &self,
        sys: &mut dyn SystemState,
        report: &FailureReport,
    ) -> Result<(), TransactionError> {
        let sets = sys
            .validators()
            .current_sets()
            .map_err(TransactionError::State)?;
        let authorities: Vec<AccountId> = sets
            .current
            .validators
            .iter()
            .map(|v| v.account_id)
            .collect();
        let quarantined = sys
            .quarantine()
            .get_all()
            .map_err(TransactionError::State)?;
        let min_live = (authorities.len() / 2) + 1;

        if !authorities.contains(&report.offender) {
            return Err(TransactionError::Invalid(
                "Offender is not an authority".into(),
            ));
        }
        if quarantined.contains(&report.offender) {
            return Ok(());
        }
        let live_after = authorities
            .len()
            .saturating_sub(quarantined.len())
            .saturating_sub(1);
        if live_after < min_live {
            return Err(TransactionError::Invalid(
                "Quarantine jeopardizes liveness".into(),
            ));
        }
        sys.quarantine_mut()
            .insert(report.offender)
            .map_err(TransactionError::State)
    }
}

impl GuardianMajorityEngine {
    /// Records one fully authenticated guardian counter against consensus
    /// coordinates rather than network arrival order.
    ///
    /// Returns `true` for a new binding and `false` for exact idempotent
    /// redelivery. A different binding at the same slot is always refused.
    /// Guardian-dependent compatibility profiles additionally require a
    /// counter strictly between adjacent observed slots. Classic BFT does not:
    /// its safety authority is the authenticated quorum, not guardian state.
    pub(super) fn admit_guardian_counter_binding(
        &mut self,
        producer: AccountId,
        slot: (u64, u64),
        binding: GuardianCounterBinding,
    ) -> Result<bool, ConsensusError> {
        let invalid = |reason: &str| {
            ConsensusError::BlockVerificationFailed(format!(
                "Guardian counter {reason} for producer {} at H={} V={}",
                hex::encode(producer),
                slot.0,
                slot.1
            ))
        };

        let floor = self.guardian_counter_floors.get(&producer).copied();
        if let Some(floor) = floor {
            if slot < floor.slot {
                return Err(invalid("precedes the retained history floor"));
            }
            if slot == floor.slot {
                return if binding == floor.binding {
                    Ok(false)
                } else {
                    Err(invalid("conflicts with the retained history floor"))
                };
            }
        }

        let history = self.guardian_counter_history.entry(producer).or_default();
        if let Some(existing) = history.get(&slot) {
            return if *existing == binding {
                Ok(false)
            } else {
                Err(invalid("was rebound at an already observed slot"))
            };
        }

        // Classic BFT derives safety from authenticated quorum intersection.
        // The legacy counter/trace fields remain signature-bound wire data but
        // guardian monotonicity is not a safety assumption in this mode.
        if matches!(self.safety_mode, AftSafetyMode::ClassicBft) {
            history.insert(slot, binding);
            return Ok(true);
        }

        let predecessor = history
            .range(..slot)
            .next_back()
            .map(|(_, binding)| *binding)
            .or_else(|| floor.map(|floor| floor.binding));
        if predecessor.is_some_and(|prior| binding.counter <= prior.counter) {
            return Err(invalid("did not advance after its predecessor slot"));
        }

        if history
            .range(slot..)
            .next()
            .is_some_and(|(_, next)| binding.counter >= next.counter)
        {
            return Err(invalid("did not precede its successor slot"));
        }

        history.insert(slot, binding);
        Ok(true)
    }

    /// Bounds live counter history while retaining the newest pruned binding
    /// per producer as an immutable lower fence.
    pub(super) fn prune_guardian_counter_history(&mut self, active_height: u64) {
        let cutoff = (active_height, 0);
        let mut advanced_floors = Vec::new();
        for (producer, history) in &mut self.guardian_counter_history {
            if let Some((&slot, &binding)) = history.range(..cutoff).next_back() {
                advanced_floors.push((*producer, GuardianCounterFloor { slot, binding }));
            }
            history.retain(|slot, _| *slot >= cutoff);
        }
        self.guardian_counter_history
            .retain(|_, history| !history.is_empty());

        for (producer, floor) in advanced_floors {
            match self.guardian_counter_floors.entry(producer) {
                std::collections::hash_map::Entry::Occupied(mut existing)
                    if floor.slot > existing.get().slot =>
                {
                    existing.insert(floor);
                }
                std::collections::hash_map::Entry::Vacant(entry) => {
                    entry.insert(floor);
                }
                _ => {}
            }
        }
    }
}

#[async_trait]
impl<T: Clone + Send + 'static + parity_scale_codec::Encode> ConsensusEngine<T>
    for GuardianMajorityEngine
{
    async fn decide(
        &mut self,
        our_account_id: &AccountId,
        height: u64,
        _view_arg: u64,
        parent_view: &dyn AnchoredStateView,
        known_peers: &HashSet<PeerId>,
    ) -> ConsensusDecision<T> {
        // Harvest keys from peers the transport already authenticated. An
        // Ed25519 peer id inlines its own public key, so this recovers the raw
        // key material that validator records only bind by hash. It grants no
        // authority: a key still has to match an authorized record to count.
        self.learn_authenticated_peer_keys(known_peers);

        // 1. Poll the Commit Guard
        // Ready commits only become internal finality once their committed slot is
        // also backed by the canonical collapse surface in Asymptote mode.
        loop {
            let Some(ready_commit) = self.safety.next_ready_commit() else {
                break;
            };
            let collapse_backed = if matches!(self.safety_mode, AftSafetyMode::Asymptote) {
                self.quorum_certificate_is_collapse_backed(&ready_commit, parent_view)
                    .await
                    .unwrap_or(false)
            } else {
                true
            };
            if !collapse_backed {
                debug!(
                    target: "consensus",
                    height = ready_commit.height,
                    view = ready_commit.view,
                    "Deferring ready commit until the corresponding canonical collapse object is available"
                );
                break;
            }
            if let Some(finalized_qc) = self.safety.accept_next_ready_commit() {
                info!(
                    target: "consensus",
                    "Safety Gadget: Finalized height {}",
                    finalized_qc.height
                );
                // Only here, after the two-chain rule, the guard timer, and the
                // collapse gate have all passed. `finalized_qc` is the
                // finalized block's own certificate, not the child certificate
                // whose arrival triggered the commit.
                self.queue_finalized_quorum_event(&finalized_qc);
            } else {
                break;
            }
        }

        info!(target: "consensus", "GuardianMajorityEngine::decide called for height {}", height);

        if Self::benchmark_trace_enabled() && height <= 3 {
            let root = parent_view.state_root();
            let root_prefix_len = root.len().min(4);
            eprintln!(
                "[BENCH-AFT-DECIDE] height={} parent_height={} parent_root_len={} parent_root={}",
                height,
                parent_view.height(),
                root.len(),
                hex::encode(&root[..root_prefix_len]),
            );
        }

        let vs_bytes = match parent_view.get(VALIDATOR_SET_KEY).await {
            Ok(Some(b)) => b,
            Ok(None) => {
                if Self::benchmark_trace_enabled() {
                    eprintln!(
                        "[BENCH-AFT-DECIDE] height={} decision=stall reason=missing_validator_set",
                        height
                    );
                }
                return ConsensusDecision::Stall;
            }
            Err(error) => {
                if Self::benchmark_trace_enabled() {
                    eprintln!(
                        "[BENCH-AFT-DECIDE] height={} decision=stall reason=validator_set_read_error error={}",
                        height,
                        error
                    );
                }
                return ConsensusDecision::Stall;
            }
        };
        let sets = match read_validator_sets(&vs_bytes) {
            Ok(s) => s,
            Err(error) => {
                if Self::benchmark_trace_enabled() {
                    eprintln!(
                        "[BENCH-AFT-DECIDE] height={} decision=stall reason=validator_set_decode_error error={}",
                        height,
                        error
                    );
                }
                return ConsensusDecision::Stall;
            }
        };

        let quarantined: BTreeSet<AccountId> =
            match parent_view.get(QUARANTINED_VALIDATORS_KEY).await {
                Ok(Some(b)) => codec::from_bytes_canonical(&b).unwrap_or_default(),
                _ => BTreeSet::new(),
            };

        let vs = effective_set_for_height(&sets, height);
        match self.hydrate_effective_validator_keys(parent_view, vs).await {
            Ok(true) => {}
            Ok(false) => warn!(
                target: "consensus",
                height,
                "Some effective validator keys are unavailable; their votes and certificates remain ineligible"
            ),
            Err(error) => {
                error!(
                    target: "consensus",
                    height,
                    %error,
                    "Refusing AFT progress after canonical validator-key substitution or read failure"
                );
                if Self::benchmark_trace_enabled() {
                    eprintln!(
                        "[BENCH-AFT-DECIDE] height={} decision=stall reason=validator_key_hydration error={}",
                        height, error
                    );
                }
                return ConsensusDecision::Stall;
            }
        }
        let active_validators: Vec<AccountId> = vs
            .validators
            .iter()
            .map(|v| v.account_id)
            .filter(|id| !quarantined.contains(id))
            .collect();
        self.cached_validator_count = active_validators.len();

        if active_validators.is_empty() {
            if Self::benchmark_trace_enabled() {
                eprintln!(
                    "[BENCH-AFT-DECIDE] height={} decision=stall reason=no_active_validators",
                    height
                );
            }
            return ConsensusDecision::Stall;
        }
        self.remember_validator_count(height, active_validators.len());
        // Retain the authoritative sets so `handle_vote`, which carries no
        // state view, can still authenticate against real membership.
        self.remember_validator_sets(height, &sets);
        let normative_pq_profile = matches!(self.safety_mode, AftSafetyMode::ClassicBft)
            && vs
                .validators
                .iter()
                .all(|validator| validator.consensus_key.suite == SignatureSuite::ML_DSA_44);
        if matches!(self.safety_mode, AftSafetyMode::ClassicBft) && !normative_pq_profile {
            error!(target: "consensus", height, "AFT PQ v1 refuses a classic_bft membership containing a non-ML-DSA consensus key");
            return ConsensusDecision::Stall;
        }

        if self.pacemaker_height != height {
            self.pacemaker.lock().await.start_height();
            self.pacemaker_height = height;
        }
        if self.fallback_starts.contains_key(&height) {
            debug!(target: "consensus", height, "Optimistic decision path is fenced after durable fallback start");
            return ConsensusDecision::Stall;
        }
        let mut current_view = { self.pacemaker.lock().await.current_view };
        let bootstrap_first_commit_pending =
            height == 1 && self.highest_qc.height == 0 && !self.committed_headers.contains_key(&1);
        let pin_bootstrap_view_zero = bootstrap_first_commit_pending
            || (height <= 3 && Instant::now() < self.bootstrap_grace_until);

        if pin_bootstrap_view_zero {
            if let Ok(mut pacemaker) = self.pacemaker.try_lock() {
                pacemaker.current_view = 0;
                pacemaker.view_start_time = Instant::now();
            }
            current_view = 0;
            if bootstrap_first_commit_pending {
                self.timeout_votes_sent
                    .retain(|(vote_height, _), _| *vote_height != height);
                self.tc_formed.retain(|(tc_height, _)| *tc_height != height);
            }
            if Self::benchmark_trace_enabled() {
                eprintln!(
                    "[BENCH-AFT-DECIDE] height={} decision=pin_view0 reason={}",
                    height,
                    if bootstrap_first_commit_pending {
                        "bootstrap_first_commit_pending"
                    } else {
                        "bootstrap_grace"
                    }
                );
            }
            debug!(
                target: "consensus",
                height,
                bootstrap_first_commit_pending,
                "Pinning the bootstrap view to 0."
            );
        }

        if !bootstrap_first_commit_pending {
            let tc_views = if normative_pq_profile {
                self.aft_timeout_votes
                    .get(&height)
                    .map(|view_map| view_map.keys().copied().collect::<Vec<_>>())
                    .unwrap_or_default()
            } else {
                self.view_votes
                    .get(&height)
                    .map(|view_map| view_map.keys().copied().collect::<Vec<_>>())
                    .unwrap_or_default()
            };
            let mut newest_tc_view = current_view;
            for view in tc_views {
                if self.tc_formed.contains(&(height, view)) {
                    newest_tc_view = newest_tc_view.max(view);
                    continue;
                }
                let adopted = if normative_pq_profile {
                    let certificate = match self.check_aft_timeout_quorum(height, view, &sets) {
                        Ok(certificate) => certificate,
                        Err(error) => {
                            error!(target: "consensus", height, view, %error, "Refusing scoped timeout quorum");
                            return ConsensusDecision::Stall;
                        }
                    };
                    if let Some(certificate) = certificate {
                        self.adopt_aft_timeout_certificate(certificate, false).await
                    } else {
                        Ok(false)
                    }
                } else if let Some(certificate) =
                    self.check_quorum(height, view, vs.total_weight, &sets)
                {
                    self.adopt_timeout_certificate(certificate, false).await
                } else {
                    Ok(false)
                };
                match adopted {
                    Ok(true) => {
                        info!(
                            target: "consensus",
                            height,
                            view,
                            "Majority quorum reached for view change. Advancing pacemaker."
                        );
                    }
                    Ok(false) => {}
                    Err(error) => {
                        error!(
                            target: "consensus",
                            height,
                            view,
                            %error,
                            "Refusing timeout-certificate transition"
                        );
                        return ConsensusDecision::Stall;
                    }
                }
                if self.tc_formed.contains(&(height, view)) {
                    newest_tc_view = newest_tc_view.max(view);
                }
            }
            if newest_tc_view > current_view {
                self.pacemaker.lock().await.advance_view(newest_tc_view);
                current_view = newest_tc_view;
            }

            // Adopting the third scoped TC above may have durably installed
            // fallback. No optimistic timeout, proposal, or vote authority is
            // issued beyond that transition point.
            if self.fallback_starts.contains_key(&height) {
                debug!(target: "consensus", height, "Optimistic decision path fenced by newly persisted fallback start");
                return ConsensusDecision::Stall;
            }

            let timed_out = { self.pacemaker.lock().await.check_timeout() };
            if timed_out {
                let next_view = current_view + 1;
                let now = Instant::now();
                let should_relay = self
                    .timeout_votes_sent
                    .get(&(height, next_view))
                    .is_none_or(|last_relay| {
                        now.duration_since(*last_relay) >= Duration::from_secs(1)
                    });
                if should_relay {
                    self.timeout_votes_sent.insert((height, next_view), now);
                    if Self::benchmark_trace_enabled() {
                        eprintln!(
                            "[BENCH-AFT-DECIDE] height={} decision=timeout current_view={} next_view={} reason=pacemaker_timed_out",
                            height,
                            current_view,
                            next_view
                        );
                    }
                    info!(
                        target: "consensus",
                        height,
                        current_view,
                        next_view,
                        "Pacemaker timed out. Emitting a view change vote and waiting for a timeout certificate."
                    );
                    return ConsensusDecision::Timeout {
                        view: next_view,
                        height,
                    };
                }
                debug!(
                    target: "consensus",
                    height,
                    current_view,
                    next_view,
                    "Timeout vote already emitted for the next view; waiting for a timeout certificate."
                );
                if Self::benchmark_trace_enabled() {
                    eprintln!(
                        "[BENCH-AFT-DECIDE] height={} decision=wait_for_block current_view={} next_view={} reason=timeout_vote_already_emitted",
                        height,
                        current_view,
                        next_view
                    );
                }
                return ConsensusDecision::WaitForBlock;
            }

            if current_view > 0 && !self.tc_formed.contains(&(height, current_view)) {
                if Self::benchmark_trace_enabled() {
                    eprintln!(
                        "[BENCH-AFT-DECIDE] height={} decision=wait_for_block current_view={} reason=awaiting_timeout_certificate",
                        height,
                        current_view
                    );
                }
                debug!(
                    target: "consensus",
                    height,
                    current_view,
                    "Waiting for timeout certificate before entering the next view."
                );
                return ConsensusDecision::WaitForBlock;
            }
        }

        let parent_root = parent_view.state_root();
        self.mirror_seed = ioi_crypto::algorithms::hash::sha256(parent_root).unwrap_or([0u8; 32]);

        let n = active_validators.len() as u64;
        let round_index = height.saturating_sub(1).saturating_add(current_view);
        let leader_index = (round_index % n) as usize;
        let leader_id = active_validators[leader_index];
        if height == 1 {
            eprintln!(
                "[AFT-LEADER] local={} leader={} validator_count={} known_peer_count={}",
                hex::encode(&our_account_id.0[..4]),
                hex::encode(&leader_id.0[..4]),
                active_validators.len(),
                known_peers.len(),
            );
            info!(
                target: "consensus",
                height,
                current_view,
                local = %hex::encode(&our_account_id.0[..4]),
                leader = %hex::encode(&leader_id.0[..4]),
                validator_count = active_validators.len(),
                known_peer_count = known_peers.len(),
                "GuardianMajority leader selection for the first height."
            );
        }
        if known_peers.is_empty() && leader_id != *our_account_id {
            if Self::benchmark_trace_enabled() {
                eprintln!(
                    "[BENCH-AFT-DECIDE] height={} decision=stall current_view={} reason=no_peers_not_leader",
                    height,
                    current_view
                );
            }
            debug!(target: "consensus", "Stalling: No peers and not leader (Me: {:?}, Leader: {:?})", our_account_id, leader_id);
            return ConsensusDecision::Stall;
        }

        if leader_id == *our_account_id {
            let parent_qc = if height > 1 {
                if matches!(self.safety_mode, AftSafetyMode::ClassicBft) {
                    // The locally committed parent identifies the only block a
                    // child may extend, but it is not quorum evidence. Classic
                    // BFT must wait until the exact parent carries either a
                    // currently authenticated 2f+1 native certificate or the
                    // separately verified typed async-parent proof. In
                    // particular, never
                    // promote `synthetic_parent_qc_for_height` into authority:
                    // that helper is an unsigned coordinate/recovery surface.
                    let expected_parent = self.synthetic_parent_qc_for_height(height);
                    let authenticated_parent = expected_parent.as_ref().is_some_and(|expected| {
                        self.highest_qc.height == expected.height
                            && self.highest_qc.view == expected.view
                            && self.highest_qc.block_hash == expected.block_hash
                            && (self.authenticated_quorum(&self.highest_qc).is_ok()
                                || self.has_async_parent_proof(&self.highest_qc))
                    });
                    if !authenticated_parent {
                        if Self::benchmark_trace_enabled() {
                            eprintln!(
                                "[BENCH-AFT-DECIDE] height={} decision=wait_for_block current_view={} highest_qc_height={} reason=classic_bft_awaiting_authenticated_parent_qc",
                                height,
                                current_view,
                                self.highest_qc.height
                            );
                        }
                        debug!(
                            target: "consensus",
                            height,
                            current_view,
                            highest_qc_height = self.highest_qc.height,
                            expected_parent_height = expected_parent.as_ref().map(|qc| qc.height),
                            "Classic BFT leader is waiting for an authenticated certificate over the exact committed parent."
                        );
                        return ConsensusDecision::WaitForBlock;
                    }
                    self.highest_qc.clone()
                } else {
                    let progress_parent_qc = if matches!(self.safety_mode, AftSafetyMode::Asymptote)
                    {
                        self.collapse_backed_parent_qc_for_height(height, parent_view)
                            .await
                            .ok()
                            .flatten()
                    } else {
                        self.synthetic_parent_qc_for_height(height)
                    };
                    if let Some(synthetic_parent_qc) = progress_parent_qc {
                        let highest_qc_at_parent_height = self.highest_qc.height == height - 1;
                        let highest_qc_has_local_header =
                            if matches!(self.safety_mode, AftSafetyMode::Asymptote) {
                                highest_qc_at_parent_height
                                    && self
                                        .quorum_certificate_is_collapse_backed(
                                            &self.highest_qc,
                                            parent_view,
                                        )
                                        .await
                                        .unwrap_or(false)
                            } else {
                                highest_qc_at_parent_height
                                    && self.qc_has_local_restart_context(&self.highest_qc)
                            };

                        if self.highest_qc.height < height - 1
                            || (highest_qc_at_parent_height && !highest_qc_has_local_header)
                        {
                            if highest_qc_at_parent_height
                                && self.highest_qc.block_hash != synthetic_parent_qc.block_hash
                                && !highest_qc_has_local_header
                            {
                                info!(
                                    target: "consensus",
                                    height,
                                    current_view,
                                    highest_qc_height = self.highest_qc.height,
                                    highest_qc_hash = %hex::encode(&self.highest_qc.block_hash[..4]),
                                    synthetic_parent_hash = %hex::encode(&synthetic_parent_qc.block_hash[..4]),
                                    "Replacing a headerless parent-height QC with the locally committed synthetic parent QC."
                                );
                            }
                            self.highest_qc = synthetic_parent_qc.clone();
                            synthetic_parent_qc
                        } else {
                            self.highest_qc.clone()
                        }
                    } else if self.highest_qc.height < height - 1
                        || (matches!(self.safety_mode, AftSafetyMode::Asymptote)
                            && self.highest_qc.height == height - 1
                            && !self
                                .quorum_certificate_is_collapse_backed(
                                    &self.highest_qc,
                                    parent_view,
                                )
                                .await
                                .unwrap_or(false))
                    {
                        let next_view = current_view + 1;
                        let now = Instant::now();
                        let should_relay = self
                            .timeout_votes_sent
                            .get(&(height, next_view))
                            .is_none_or(|last_relay| {
                                now.duration_since(*last_relay) >= Duration::from_secs(1)
                            });
                        if should_relay {
                            self.timeout_votes_sent.insert((height, next_view), now);
                            if Self::benchmark_trace_enabled() {
                                eprintln!(
                                "[BENCH-AFT-DECIDE] height={} decision=timeout current_view={} next_view={} highest_qc_height={} reason=leader_missing_parent_qc",
                                height,
                                current_view,
                                next_view,
                                self.highest_qc.height
                            );
                            }
                            info!(
                                target: "consensus",
                                height,
                                current_view,
                                next_view,
                                highest_qc_height = self.highest_qc.height,
                                "Leader lacks a quorum certificate for the parent height. Emitting a view change vote."
                            );
                            return ConsensusDecision::Timeout {
                                view: next_view,
                                height,
                            };
                        }
                        debug!(
                            target: "consensus",
                            height,
                            current_view,
                            next_view,
                            highest_qc_height = self.highest_qc.height,
                            "Leader is still waiting for a timeout certificate after requesting a view change."
                        );
                        if Self::benchmark_trace_enabled() {
                            eprintln!(
                            "[BENCH-AFT-DECIDE] height={} decision=wait_for_block current_view={} next_view={} highest_qc_height={} reason=leader_waiting_after_parent_qc_timeout",
                            height,
                            current_view,
                            next_view,
                            self.highest_qc.height
                        );
                        }
                        return ConsensusDecision::WaitForBlock;
                    } else {
                        self.highest_qc.clone()
                    }
                }
            } else {
                self.highest_qc.clone()
            };

            // Safety Check: Ensure we don't propose conflicting blocks
            // Use locked_qc from safety gadget to ensure we extend the correct chain
            if let Some(_locked) = &self.safety.locked_qc {
                // If we have a lock, we must extend it.
                // For simplified Aft deterministic, the highest_qc usually matches the lock or is newer.
                // The proposal construction in `create_block` uses `highest_qc` (via `parent_qc` logic).
            }

            let timing_params = match parent_view.get(BLOCK_TIMING_PARAMS_KEY).await {
                Ok(Some(b)) => {
                    codec::from_bytes_canonical::<BlockTimingParams>(&b).unwrap_or_default()
                }
                _ => {
                    if Self::benchmark_trace_enabled() {
                        eprintln!(
                            "[BENCH-AFT-DECIDE] height={} decision=stall current_view={} reason=missing_timing_params",
                            height,
                            current_view
                        );
                    }
                    return ConsensusDecision::Stall;
                }
            };
            let timing_runtime = match parent_view.get(BLOCK_TIMING_RUNTIME_KEY).await {
                Ok(Some(b)) => {
                    codec::from_bytes_canonical::<BlockTimingRuntime>(&b).unwrap_or_default()
                }
                _ => {
                    if Self::benchmark_trace_enabled() {
                        eprintln!(
                            "[BENCH-AFT-DECIDE] height={} decision=stall current_view={} reason=missing_timing_runtime",
                            height,
                            current_view
                        );
                    }
                    return ConsensusDecision::Stall;
                }
            };
            let mut parent_status: ChainStatus = match parent_view.get(STATUS_KEY).await {
                Ok(Some(b)) => codec::from_bytes_canonical(&b).unwrap_or_default(),
                Ok(None) if height == 1 => ChainStatus::default(),
                _ => {
                    if Self::benchmark_trace_enabled() {
                        eprintln!(
                            "[BENCH-AFT-DECIDE] height={} decision=stall current_view={} reason=missing_parent_status",
                            height,
                            current_view
                        );
                    }
                    return ConsensusDecision::Stall;
                }
            };
            // Externally composed test fixtures can carry signed wall-clock
            // evidence before their fresh deterministic AFT chain has
            // produced height one.  Genesis may contain either no status or a
            // default zero-timestamp status, so bridge both representations.
            // The first ordinary block durably publishes this clock through
            // ChainStatus.  The explicit testing namespace keeps production
            // chains on their state-derived clock.
            if height == 1 && parent_status.latest_timestamp_ms_or_legacy() == 0 {
                if let Some(timestamp_ms) = std::env::var("IOI_TESTING_INITIAL_TIP_TIMESTAMP_MS")
                    .ok()
                    .and_then(|value| value.parse::<u64>().ok())
                    .filter(|value| *value > 0)
                {
                    parent_status.set_latest_timestamp_ms(timestamp_ms);
                }
            }

            let expected_ts_ms = compute_next_timestamp_ms(
                &timing_params,
                &timing_runtime,
                height.saturating_sub(1),
                parent_status.latest_timestamp_ms_or_legacy(),
                0,
            )
            .unwrap_or_else(|| parent_status.latest_timestamp_ms_or_legacy());
            let expected_ts = timestamp_millis_to_legacy_seconds(expected_ts_ms);

            let (timeout_certificate, aft_timeout_certificate) = if current_view > 0 {
                if normative_pq_profile {
                    match self.check_aft_timeout_quorum(height, current_view, &sets) {
                        Ok(certificate) => (None, certificate),
                        Err(error) => {
                            error!(target: "consensus", height, current_view, %error, "Refusing malformed scoped timeout quorum during proposal construction");
                            return ConsensusDecision::Stall;
                        }
                    }
                } else {
                    (
                        self.check_quorum(height, current_view, vs.total_weight, &sets),
                        None,
                    )
                }
            } else {
                (None, None)
            };

            let (
                previous_canonical_collapse_commitment_hash,
                canonical_collapse_extension_certificate,
            ) = if height <= 1 {
                ([0u8; 32], None)
            } else {
                match self
                    .canonical_collapse_extension_certificate_for_height(height, parent_view)
                    .await
                {
                    Ok((hash, certificate)) => (hash, Some(certificate)),
                    Err(error) => {
                        debug!(
                            target: "consensus",
                            height,
                            current_view,
                            error = %error,
                            "Stalling block production until the canonical collapse extension certificate is available"
                        );
                        return ConsensusDecision::Stall;
                    }
                }
            };

            info!(target: "consensus", "I am leader for H={} V={}. Producing block.", height, current_view);

            ConsensusDecision::ProduceBlock {
                transactions: vec![],
                expected_timestamp_secs: expected_ts,
                expected_timestamp_ms: expected_ts_ms,
                view: current_view,
                parent_qc,
                previous_canonical_collapse_commitment_hash,
                canonical_collapse_extension_certificate,
                timeout_certificate,
                aft_timeout_certificate,
            }
        } else {
            ConsensusDecision::WaitForBlock
        }
    }

    async fn handle_block_proposal<CS, ST>(
        &mut self,
        block: Block<T>,
        chain_view: &dyn ChainView<CS, ST>,
    ) -> Result<(), ConsensusError>
    where
        CS: CommitmentScheme + Send + Sync,
        ST: StateManager<Commitment = CS::Commitment, Proof = CS::Proof> + Send + Sync + 'static,
    {
        if self.fallback_starts.contains_key(&block.header.height) {
            return Err(ConsensusError::BlockVerificationFailed(
                "optimistic proposal arrived after durable fallback start".into(),
            ));
        }
        if let Some(proof) = self.check_divergence(&block.header) {
            error!(target: "consensus", "CRITICAL: DIVERGENCE PROOF CONSTRUCTED: {:?}", proof);
            return Err(ConsensusError::BlockVerificationFailed(
                "Panic:HardwareDivergence".into(),
            ));
        }

        let header = &block.header;

        let parent_state_ref = StateRef {
            height: header.height - 1,
            state_root: header.parent_state_root.as_ref().to_vec(),
            block_hash: header.parent_hash,
        };
        let parent_view = chain_view
            .view_at(&parent_state_ref)
            .await
            .map_err(|e| ConsensusError::StateAccess(StateError::Backend(e.to_string())))?;

        let vs_bytes = match parent_view.get(VALIDATOR_SET_KEY).await {
            Ok(Some(b)) => b,
            Ok(None) => {
                error!(target: "consensus", "Validator set missing in parent state for H={}", header.height);
                return Err(ConsensusError::StateAccess(StateError::KeyNotFound));
            }
            Err(e) => {
                error!(target: "consensus", "State access error reading validator set: {}", e);
                return Err(ConsensusError::StateAccess(StateError::Backend(
                    e.to_string(),
                )));
            }
        };

        let sets = read_validator_sets(&vs_bytes).map_err(|e| {
            error!(target: "consensus", "Failed to decode validator set: {}", e);
            ConsensusError::BlockVerificationFailed("VS decode failed".into())
        })?;

        let quarantined: BTreeSet<AccountId> =
            match parent_view.get(QUARANTINED_VALIDATORS_KEY).await {
                Ok(Some(b)) => codec::from_bytes_canonical(&b).unwrap_or_default(),
                _ => BTreeSet::new(),
            };

        let vs = effective_set_for_height(&sets, header.height);
        if matches!(self.safety_mode, AftSafetyMode::ClassicBft)
            && vs
                .validators
                .iter()
                .any(|validator| validator.consensus_key.suite != SignatureSuite::ML_DSA_44)
        {
            return Err(ConsensusError::BlockVerificationFailed(
                "AFT PQ v1 classic_bft membership contains a non-ML-DSA consensus key".into(),
            ));
        }
        // Proposal processing is the first anchored-state edge every follower
        // must cross before accepting a block. Hydrate here as well as in
        // `decide`: a follower can receive votes or a QC before it ever runs a
        // local decision tick, especially during bootstrap or catch-up. The
        // accepted proposal then guarantees that any later commit event can
        // re-verify the exact certificate from canonical membership and keys.
        self.hydrate_effective_validator_keys(parent_view.as_ref(), vs)
            .await?;
        let active_validators: Vec<AccountId> = vs
            .validators
            .iter()
            .map(|v| v.account_id)
            .filter(|id| !quarantined.contains(id))
            .collect();
        self.remember_validator_count(header.height, active_validators.len());
        self.remember_validator_sets(header.height, &sets);

        let validator_count = active_validators.len() as u64;
        if validator_count == 0 {
            return Err(ConsensusError::BlockVerificationFailed(
                "No active validators for proposal".into(),
            ));
        }
        let round_index = header.height.saturating_sub(1).saturating_add(header.view);
        let leader_index = (round_index % validator_count) as usize;
        let expected_leader = active_validators[leader_index];
        if header.producer_account_id != expected_leader {
            return Err(ConsensusError::BlockVerificationFailed(format!(
                "Unexpected proposer for H={} V={}: expected {} got {}",
                header.height,
                header.view,
                hex::encode(expected_leader),
                hex::encode(header.producer_account_id)
            )));
        }
        let leader_record = vs
            .validators
            .iter()
            .find(|validator| validator.account_id == expected_leader)
            .ok_or_else(|| {
                ConsensusError::BlockVerificationFailed(
                    "expected AFT leader is missing its validator record".into(),
                )
            })?;
        if leader_record.consensus_key.since_height > header.height {
            return Err(ConsensusError::BlockVerificationFailed(format!(
                "AFT leader consensus key is not active until height {}",
                leader_record.consensus_key.since_height
            )));
        }
        if header.producer_key_suite != leader_record.consensus_key.suite {
            return Err(ConsensusError::BlockVerificationFailed(format!(
                "AFT producer suite {:?} does not match rooted leader suite {:?}",
                header.producer_key_suite, leader_record.consensus_key.suite
            )));
        }
        let derived_producer_key_hash =
            account_id_from_key_material(header.producer_key_suite, &header.producer_pubkey)
                .map_err(|error| {
                    ConsensusError::BlockVerificationFailed(format!(
                        "failed to derive AFT producer key hash: {error}"
                    ))
                })?;
        if derived_producer_key_hash != header.producer_pubkey_hash
            || derived_producer_key_hash != leader_record.consensus_key.public_key_hash
        {
            return Err(ConsensusError::BlockVerificationFailed(
                "AFT producer key is not the rooted consensus key authorized to the leader".into(),
            ));
        }
        if header.view == 0 {
            if header.timeout_certificate.is_some() || header.aft_timeout_certificate.is_some() {
                return Err(ConsensusError::BlockVerificationFailed(format!(
                    "Unexpected timeout certificate on view-0 proposal H={}",
                    header.height
                )));
            }
        } else {
            if header.timeout_certificate.is_some() && header.aft_timeout_certificate.is_some() {
                return Err(ConsensusError::BlockVerificationFailed(
                    "proposal carries both legacy and scoped timeout authority".into(),
                ));
            }
            if matches!(self.safety_mode, AftSafetyMode::ClassicBft) {
                let certificate = header.aft_timeout_certificate.as_ref().ok_or_else(|| {
                    ConsensusError::BlockVerificationFailed(format!(
                        "Missing scoped AFT timeout certificate for PQ proposal H={} V={}",
                        header.height, header.view
                    ))
                })?;
                if certificate.height != header.height || certificate.view != header.view {
                    return Err(ConsensusError::BlockVerificationFailed(
                        "scoped AFT timeout certificate does not authorize the proposal slot"
                            .into(),
                    ));
                }
                self.verify_aft_timeout_certificate(certificate, &sets)?;
            } else {
                let certificate = header.timeout_certificate.as_ref().ok_or_else(|| {
                    ConsensusError::BlockVerificationFailed(format!(
                        "Missing legacy timeout certificate for compatibility proposal H={} V={}",
                        header.height, header.view
                    ))
                })?;
                self.verify_timeout_certificate(certificate, &sets)?;
            }
        }

        let threshold = self.quorum_count_threshold_for_height(header.height);

        let block_hash_bytes = match header.hash() {
            Ok(h) => h,
            Err(_) => return Err(ConsensusError::BlockVerificationFailed("Hash fail".into())),
        };
        let block_hash = to_root_hash(&block_hash_bytes)
            .map_err(|_| ConsensusError::BlockVerificationFailed("Hash len".into()))?;
        // Check votes
        if let Some(votes) = self
            .vote_pool
            .get(&header.height)
            .and_then(|m| m.get(&block_hash))
        {
            if votes.len() >= threshold {
                let qc = QuorumCertificate {
                    height: header.height,
                    view: header.view,
                    block_hash,
                    signatures: votes
                        .iter()
                        .map(|v| (v.voter, v.signature.clone()))
                        .collect(),
                    aggregated_signature: vec![],
                    signers_bitfield: vec![],
                };
                self.accept_quorum_certificate(qc, true).await?;
            }
        }

        if header.height > 1 {
            let parent_qc = &header.parent_qc;
            if parent_qc.height != header.height - 1 {
                return Err(ConsensusError::BlockVerificationFailed(
                    "Parent QC height mismatch".into(),
                ));
            }
            if parent_qc.block_hash != header.parent_hash {
                return Err(ConsensusError::BlockVerificationFailed(
                    "Parent QC hash mismatch".into(),
                ));
            }
            let async_parent = matches!(self.safety_mode, AftSafetyMode::ClassicBft)
                && self.has_async_parent_proof(parent_qc);
            let parent_verification = if async_parent {
                Ok(())
            } else if matches!(self.safety_mode, AftSafetyMode::ClassicBft) {
                self.authenticated_quorum(parent_qc).map(|_| ())
            } else {
                self.verify_qc(parent_qc, &sets)
            };
            if let Err(e) = parent_verification {
                error!(
                    target: "consensus",
                    "QC Verification Failed for block {}: {}",
                    header.height,
                    e
                );
                return Err(e);
            }
            if matches!(self.safety_mode, AftSafetyMode::Asymptote)
                && !self
                    .quorum_certificate_is_collapse_backed(parent_qc, &*parent_view)
                    .await?
            {
                return Err(ConsensusError::BlockVerificationFailed(format!(
                    "Parent QC is not backed by a canonical collapse object for height {}",
                    parent_qc.height
                )));
            }
            if !async_parent {
                self.remember_qc(parent_qc);
                self.reconcile_classic_safety_qc(parent_qc);
            }
            if parent_qc.height > self.highest_qc.height {
                self.highest_qc = parent_qc.clone();
            }
        }

        let preimage = header
            .to_preimage_for_signing()
            .map_err(|e| ConsensusError::BlockVerificationFailed(e.to_string()))?;
        verify_guardian_signature(
            &preimage,
            header.producer_key_suite,
            &header.producer_pubkey,
            &header.signature,
            header.oracle_counter,
            &header.oracle_trace_hash,
        )?;
        self.verify_guardianized_certificate(header, &preimage, &*parent_view)
            .await?;
        if matches!(self.safety_mode, AftSafetyMode::Asymptote) {
            self.canonical_collapse_from_header_surface_with_parent_view(header, &*parent_view)
                .await?;
            self.verify_published_canonical_collapse_object(header, &*parent_view)
                .await?;
        }

        // Only a fully verified proposal may move the pacemaker. Views are
        // scoped to one height, so a proposal for a newer height first resets
        // the view sequence instead of inheriting the prior height's view.
        {
            let mut pacemaker = self.pacemaker.lock().await;
            if header.height > self.pacemaker_height {
                pacemaker.start_height();
                self.pacemaker_height = header.height;
            }
            if header.height == self.pacemaker_height {
                pacemaker.observe_progress(header.view);
            }
        }

        if let Some(existing_header) = self
            .seen_headers
            .get(&(header.height, header.view))
            .and_then(|headers| headers.get(&block_hash))
            .cloned()
        {
            let same_slot_identity = existing_header.producer_account_id
                == header.producer_account_id
                && existing_header.oracle_counter == header.oracle_counter
                && existing_header.oracle_trace_hash == header.oracle_trace_hash;
            let richer_certification = existing_header.guardian_certificate
                != header.guardian_certificate
                || existing_header.sealed_finality_proof != header.sealed_finality_proof
                || existing_header.canonical_order_certificate
                    != header.canonical_order_certificate;
            if same_slot_identity && richer_certification {
                if let Some(headers) = self.seen_headers.get_mut(&(header.height, header.view)) {
                    headers.insert(block_hash, header.clone());
                }
                debug!(
                    target: "consensus",
                    height = header.height,
                    view = header.view,
                    "Accepted sealed/header enrichment for an already verified block"
                );
                return Ok(());
            }
        }

        if !self.admit_guardian_counter_binding(
            header.producer_account_id,
            (header.height, header.view),
            GuardianCounterBinding {
                counter: header.oracle_counter,
                trace_hash: header.oracle_trace_hash,
                block_hash,
            },
        )? {
            // Exact authenticated redelivery is idempotent.  It must not emit
            // another echo or perturb the pacemaker.
            return Ok(());
        }

        {
            let mut pacemaker = self.pacemaker.lock().await;
            pacemaker.observe_progress(header.view);
        }

        // A directly propagated QC may have arrived before this proposal. Now
        // that the exact signed header is verified, reconcile that early QC
        // into the same ordered commit queue.
        if let Some(qc) = self
            .qc_pool
            .get(&header.height)
            .and_then(|qcs| qcs.get(&block_hash))
            .cloned()
        {
            self.reconcile_classic_safety_qc(&qc);
        }

        debug!(target: "consensus", "Aft deterministic: Block {} verified. Initiating ECHO phase.", header.height);
        Ok(())
    }

    async fn handle_vote(&mut self, vote: ConsensusVote) -> Result<(), ConsensusError> {
        if self.fallback_starts.contains_key(&vote.height) {
            return Err(ConsensusError::BlockVerificationFailed(format!(
                "optimistic vote arrived after durable fallback start at H={} V={}",
                vote.height, vote.view
            )));
        }
        // Authenticate before the vote can influence any quorum. A vote that
        // fails here never reaches the pool, so it can never be counted toward
        // a threshold nor appear in a certificate this node assembles.
        self.authenticated_vote(&vote)?;

        // Safety Check: Don't process votes if not safe
        if !self.safety.safe_to_vote(vote.view, vote.height - 1) {
            // Logic for unsafe vote handling (optional)
        }

        let threshold = self.quorum_count_threshold_for_height(vote.height);
        let height_map = self.vote_pool.entry(vote.height).or_default();
        if height_map.iter().any(|(block_hash, pooled)| {
            *block_hash != vote.block_hash
                && pooled
                    .iter()
                    .any(|prior| prior.voter == vote.voter && prior.view == vote.view)
        }) {
            return Err(ConsensusError::BlockVerificationFailed(format!(
                "Validator {} equivocated at H={} V={}",
                hex::encode(vote.voter),
                vote.height,
                vote.view
            )));
        }
        let votes = height_map.entry(vote.block_hash).or_default();

        if votes.iter().any(|v| v.voter == vote.voter) {
            return Ok(());
        }
        votes.push(vote.clone());

        // Only votes cast in the certificate's own view may back it. Each vote
        // signed a preimage that commits to its view, so mixing views would
        // assemble a certificate whose own signatures cannot verify against it.
        // In practice a block hash binds one view, so this changes nothing on
        // the normal path.
        let votes: Vec<ConsensusVote> = votes
            .iter()
            .filter(|pooled| pooled.view == vote.view)
            .cloned()
            .collect();

        if votes.len() >= threshold {
            let qc = QuorumCertificate {
                height: vote.height,
                view: vote.view,
                block_hash: vote.block_hash,
                signatures: votes
                    .iter()
                    .map(|v| (v.voter, v.signature.clone()))
                    .collect(),
                aggregated_signature: vec![],
                signers_bitfield: vec![],
            };
            self.accept_quorum_certificate(qc, true).await?;
        }
        Ok(())
    }

    async fn handle_quorum_certificate(
        &mut self,
        qc: QuorumCertificate,
    ) -> Result<(), ConsensusError> {
        self.accept_quorum_certificate(qc, false).await
    }

    async fn handle_timeout_certificate(
        &mut self,
        certificate: TimeoutCertificate,
    ) -> Result<(), ConsensusError> {
        self.adopt_timeout_certificate(certificate, true)
            .await
            .map(|_| ())
    }

    async fn handle_aft_timeout_vote(
        &mut self,
        from: PeerId,
        vote: AftTimeoutVoteV1,
    ) -> Result<(), ConsensusError> {
        if self.pacemaker_height > 0 && vote.height < self.pacemaker_height {
            return Err(ConsensusError::BlockVerificationFailed(format!(
                "stale AFT timeout vote for height {} below active height {}",
                vote.height, self.pacemaker_height
            )));
        }
        if vote.height > self.pacemaker_height.saturating_add(1) {
            return Err(ConsensusError::BlockVerificationFailed(format!(
                "future AFT timeout vote for height {} exceeds active height {}",
                vote.height, self.pacemaker_height
            )));
        }
        let active_view = self.pacemaker.lock().await.current_view;
        if vote.height == self.pacemaker_height && vote.view > active_view.saturating_add(1) {
            return Err(ConsensusError::BlockVerificationFailed(format!(
                "future AFT timeout vote view {} skips active view {}",
                vote.view, active_view
            )));
        }
        self.authenticated_aft_timeout_vote(&vote)?;
        info!(target: "consensus", "Scoped AFT timeout vote H={} V={} from {}", vote.height, vote.view, from);
        self.aft_timeout_votes
            .entry(vote.height)
            .or_default()
            .entry(vote.view)
            .or_default()
            .insert(vote.voter, vote);
        Ok(())
    }

    async fn handle_aft_timeout_certificate(
        &mut self,
        certificate: AftTimeoutCertificateV1,
    ) -> Result<(), ConsensusError> {
        self.adopt_aft_timeout_certificate(certificate, true)
            .await
            .map(|_| ())
    }

    async fn handle_fallback_start_certificate(
        &mut self,
        certificate: FallbackStartCertificateV1,
    ) -> Result<(), ConsensusError> {
        self.adopt_fallback_start(certificate).map(|_| ())
    }

    fn observe_aft_async_parent_proof(
        &mut self,
        proof: AftAsyncParentProofV1,
    ) -> Result<(), ConsensusError> {
        self.accept_async_parent_proof(proof)
    }

    fn aft_timeout_safe_state(&self, height: u64) -> Option<AftTimeoutSafeStateV1> {
        if height == 0 || self.highest_qc.height >= height {
            return None;
        }
        let locked_qc = self.safety.locked_qc.clone().unwrap_or_default();
        if locked_qc.height > self.highest_qc.height {
            return None;
        }
        Some(AftTimeoutSafeStateV1 {
            highest_qc_async_parent_proof_hash: self.async_parent_proof_hash(&self.highest_qc),
            locked_qc_async_parent_proof_hash: self.async_parent_proof_hash(&locked_qc),
            highest_qc: self.highest_qc.clone(),
            locked_qc,
        })
    }

    fn aft_timeout_vote_for_relay(
        &self,
        height: u64,
        view: u64,
        voter: &AccountId,
    ) -> Option<AftTimeoutVoteV1> {
        self.aft_timeout_votes
            .get(&height)?
            .get(&view)?
            .get(voter)
            .cloned()
    }

    fn configure_fallback_journal(
        &mut self,
        scope: AftFallbackScopeV1,
        path: &std::path::Path,
    ) -> Result<(), ConsensusError> {
        self.configure_fallback_transition_journal(scope, path)
    }

    async fn handle_view_change(
        &mut self,
        from: PeerId,
        proof_bytes: &[u8],
    ) -> Result<(), ConsensusError> {
        let vote: ViewChangeVote =
            ioi_types::codec::from_bytes_canonical(proof_bytes).map_err(|e| {
                ConsensusError::BlockVerificationFailed(format!("Invalid view vote: {}", e))
            })?;

        // A timeout vote changes who may produce the next block. It therefore
        // receives the same membership, key-epoch and signature binding as a
        // block vote before it can contribute to a timeout certificate.
        self.authenticated_view_change_vote(&vote)?;

        info!(target: "consensus", "ViewChange vote H={} V={} from {}", vote.height, vote.view, from);
        let height_map = self.view_votes.entry(vote.height).or_default();
        let view_map = height_map.entry(vote.view).or_default();
        view_map.insert(vote.voter, vote);
        Ok(())
    }

    fn reset(&mut self, height: u64) {
        self.reset_cache_for_height(height);
    }

    fn observe_committed_block(
        &mut self,
        header: &BlockHeader,
        collapse: Option<&CanonicalCollapseObject>,
    ) -> bool {
        self.record_committed_block(header, collapse)
    }

    fn canonical_collapse_for_committed_height(
        &self,
        height: u64,
    ) -> Option<CanonicalCollapseObject> {
        self.committed_collapses.get(&height).cloned()
    }

    fn observe_aft_recovered_consensus_header(
        &mut self,
        header: &AftRecoveredConsensusHeaderEntry,
    ) -> bool {
        self.store_aft_recovered_consensus_header(header)
    }

    fn observe_aft_recovered_certified_header(
        &mut self,
        entry: &AftRecoveredCertifiedHeaderEntry,
    ) -> bool {
        self.store_aft_recovered_certified_header(entry)
    }

    fn aft_recovered_consensus_header_for_quorum_certificate(
        &self,
        qc: &QuorumCertificate,
    ) -> Option<AftRecoveredConsensusHeaderEntry> {
        self.recovered_consensus_header_for_quorum_certificate(qc)
    }

    fn aft_recovered_certified_header_for_quorum_certificate(
        &self,
        qc: &QuorumCertificate,
    ) -> Option<AftRecoveredCertifiedHeaderEntry> {
        self.recovered_certified_header_for_quorum_certificate(qc)
    }

    fn observe_aft_recovered_restart_header(
        &mut self,
        entry: &AftRecoveredRestartHeaderEntry,
    ) -> bool {
        self.store_aft_recovered_restart_header(entry)
    }

    fn aft_recovered_restart_header_for_quorum_certificate(
        &self,
        qc: &QuorumCertificate,
    ) -> Option<AftRecoveredRestartHeaderEntry> {
        self.recovered_restart_header_for_quorum_certificate(qc)
    }

    fn retain_recovered_ancestry_ranges(&mut self, keep_ranges: &[(u64, u64)]) {
        self.retain_recovered_ancestry_cache_ranges(keep_ranges);
    }

    fn header_for_quorum_certificate(&self, qc: &QuorumCertificate) -> Option<BlockHeader> {
        self.header_for_quorum_certificate_hint(qc)
    }

    fn take_pending_quorum_certificates(&mut self) -> Vec<QuorumCertificate> {
        self.drain_pending_quorum_certificates()
    }

    fn take_pending_timeout_certificates(&mut self) -> Vec<TimeoutCertificate> {
        self.drain_pending_timeout_certificates()
    }

    fn take_pending_aft_timeout_certificates(&mut self) -> Vec<AftTimeoutCertificateV1> {
        self.drain_pending_aft_timeout_certificates()
    }

    fn take_pending_fallback_starts(&mut self) -> Vec<FallbackStartCertificateV1> {
        self.drain_pending_fallback_starts()
    }

    fn drain_finalized_native_quorums(&mut self) -> Vec<NativeAftFinalizedEvidence> {
        self.promote_ready_ungated_finality();
        self.take_finalized_quorum_events()
            .into_iter()
            .map(Into::into)
            .collect()
    }

    fn observe_admitted_finality_height(&mut self, height: u64) -> bool {
        self.safety.observe_admitted_finality_height(height)
    }

    fn observe_validator_public_key(&mut self, protobuf_public_key: &[u8]) -> bool {
        self.record_validator_public_key(protobuf_public_key)
    }

    fn observe_validator_sets(&mut self, height: u64, sets: &ValidatorSetsV1) -> bool {
        self.remember_validator_count(
            height,
            effective_set_for_height(sets, height).validators.len(),
        );
        self.remember_validator_sets(height, sets);
        true
    }
}
