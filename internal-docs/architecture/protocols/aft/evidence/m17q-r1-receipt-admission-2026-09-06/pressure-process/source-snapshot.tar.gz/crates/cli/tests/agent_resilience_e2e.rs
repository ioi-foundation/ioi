// Path: crates/cli/tests/agent_resilience_e2e.rs
#![cfg(all(feature = "consensus-aft", feature = "vm-wasm"))]

use anyhow::{Context, Result};
use async_trait::async_trait;
use ioi_api::services::access::ServiceDirectory;
use ioi_api::services::BlockchainService;
use ioi_api::state::StateAccess;
use ioi_api::transaction::context::TxContext;
use ioi_api::vm::drivers::gui::{GuiDriver, InputEvent};
use ioi_api::vm::inference::InferenceRuntime;
use ioi_cli::testing::build_test_artifacts;
use ioi_drivers::browser::BrowserDriver;
use ioi_drivers::terminal::TerminalDriver;
use ioi_memory::MemoryRuntime;
use ioi_services::agentic::rules::DefaultPolicy;
use ioi_services::agentic::runtime::keys::AGENT_POLICY_PREFIX;
use ioi_services::agentic::runtime::service::decision_loop::helpers::default_safe_policy;
use ioi_services::agentic::runtime::types::{ExecutionTier, PostMessageParams};
use ioi_services::agentic::runtime::{
    AgentMode, AgentState, AgentStatus, RuntimeAgentService, StartAgentParams, StepAgentParams,
};
use ioi_state::primitives::hash::HashCommitmentScheme;
use ioi_state::tree::iavl::IAVLTree;
use ioi_types::app::agentic::InferenceOptions;
use ioi_types::app::agentic::{
    CapabilityId, IntentConfidenceBand, IntentScopeProfile, ResolvedIntentState,
};
use ioi_types::app::{ActionRequest, ContextSlice, KernelEvent};
use ioi_types::{codec, error::VmError};
use serde_json::json;
use std::future::Future;
use std::io::Cursor;
use std::path::Path;
use std::sync::{Arc, Mutex, OnceLock};
use std::thread;
use std::time::{Instant, SystemTime, UNIX_EPOCH};
use tokio::runtime::Builder;
use tokio::sync::broadcast;

use image::{ImageBuffer, ImageFormat, Rgba};

static WEB_ENV_LOCK: OnceLock<Mutex<()>> = OnceLock::new();
const AGENT_RESILIENCE_TEST_STACK_BYTES: usize = 4 * 1024 * 1024;

fn run_agent_resilience_test<F, Fut>(test_fn: F) -> Result<()>
where
    F: FnOnce() -> Fut + Send + 'static,
    Fut: Future<Output = Result<()>> + Send + 'static,
{
    let handle = thread::Builder::new()
        .name("agent-resilience-runtime".to_string())
        .stack_size(AGENT_RESILIENCE_TEST_STACK_BYTES)
        .spawn(move || {
            Builder::new_multi_thread()
                .enable_all()
                .build()
                .context("build agent resilience Tokio runtime")?
                .block_on(test_fn())
        })
        .context("spawn agent resilience runtime thread")?;

    match handle.join() {
        Ok(result) => result,
        Err(payload) => std::panic::resume_unwind(payload),
    }
}

struct ScopedEnvVar {
    key: &'static str,
    previous: Option<String>,
}

impl ScopedEnvVar {
    fn set(key: &'static str, value: &str) -> Self {
        let previous = std::env::var(key).ok();
        std::env::set_var(key, value);
        Self { key, previous }
    }
}

impl Drop for ScopedEnvVar {
    fn drop(&mut self) {
        if let Some(prev) = &self.previous {
            std::env::set_var(self.key, prev);
        } else {
            std::env::remove_var(self.key);
        }
    }
}

#[derive(Clone)]
struct MockGuiDriver {
    fail_count: Arc<Mutex<u32>>,
}

#[async_trait]
impl GuiDriver for MockGuiDriver {
    async fn capture_screen(
        &self,
        _crop_rect: Option<(i32, i32, u32, u32)>,
    ) -> Result<Vec<u8>, VmError> {
        let mut img = ImageBuffer::<Rgba<u8>, Vec<u8>>::new(1, 1);
        img.put_pixel(0, 0, Rgba([255, 0, 0, 255]));

        let mut bytes: Vec<u8> = Vec::new();
        img.write_to(&mut Cursor::new(&mut bytes), ImageFormat::Png)
            .map_err(|e| VmError::HostError(format!("Mock PNG encoding failed: {}", e)))?;

        Ok(bytes)
    }

    async fn capture_raw_screen(&self) -> Result<Vec<u8>, VmError> {
        self.capture_screen(None).await
    }

    async fn capture_tree(&self) -> Result<String, VmError> {
        Ok("<window id=\"fixture\" name=\"Resilience Fixture\"><button id=\"recover\" name=\"Recover\" rect=\"95,95,20,20\" /></window>".to_string())
    }

    async fn capture_context(&self, _: &ActionRequest) -> Result<ContextSlice, VmError> {
        Ok(ContextSlice {
            slice_id: [0; 32],
            frame_id: 0,
            chunks: vec![],
            mhnsw_root: [0; 32],
            traversal_proof: None,
            intent_id: [0; 32],
        })
    }

    async fn inject_input(&self, _: InputEvent) -> Result<(), VmError> {
        let mut count = self.fail_count.lock().unwrap();
        if *count < 2 {
            *count += 1;
            return Err(VmError::HostError("Click drifted".into()));
        }
        Ok(())
    }

    async fn get_element_center(&self, _id: u32) -> Result<Option<(u32, u32)>, VmError> {
        Ok(None)
    }
}

struct ResilientBrain;

#[async_trait]
impl InferenceRuntime for ResilientBrain {
    async fn execute_inference(
        &self,
        _hash: [u8; 32],
        input: &[u8],
        _opts: InferenceOptions,
    ) -> Result<Vec<u8>, VmError> {
        let prompt = String::from_utf8_lossy(input);
        let tool_call = if prompt.contains("ontology incident resolver")
            || prompt.contains("Choose the next recovery action now.")
        {
            json!({
                "name": "screen__inspect",
                "arguments": {}
            })
        } else {
            json!({
                "name": "screen",
                "arguments": {
                    "action": "left_click",
                    "coordinate": [100, 100]
                }
            })
        };
        Ok(tool_call.to_string().into_bytes())
    }

    async fn load_model(&self, _: [u8; 32], _: &Path) -> Result<(), VmError> {
        Ok(())
    }

    async fn unload_model(&self, _: [u8; 32]) -> Result<(), VmError> {
        Ok(())
    }
}

struct WebTimeoutBrain;

#[async_trait]
impl InferenceRuntime for WebTimeoutBrain {
    async fn execute_inference(
        &self,
        _hash: [u8; 32],
        _input: &[u8],
        _opts: InferenceOptions,
    ) -> Result<Vec<u8>, VmError> {
        let tool_call = json!({
            "name": "web__search",
            "arguments": { "query": "latest news", "limit": 5 }
        });
        Ok(tool_call.to_string().into_bytes())
    }

    async fn load_model(&self, _: [u8; 32], _: &Path) -> Result<(), VmError> {
        Ok(())
    }

    async fn unload_model(&self, _: [u8; 32]) -> Result<(), VmError> {
        Ok(())
    }
}

fn build_ctx<'a>(services: &'a ServiceDirectory) -> TxContext<'a> {
    let now_ns = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos() as u64;
    TxContext {
        block_height: 1,
        block_timestamp: now_ns,
        chain_id: ioi_types::app::ChainId(0),
        signer_account_id: ioi_types::app::AccountId::default(),
        services,
        simulation: false,
        is_internal: false,
    }
}

fn read_agent_state(state: &IAVLTree<HashCommitmentScheme>, session_id: [u8; 32]) -> AgentState {
    let key = [b"agent::state::".as_slice(), session_id.as_slice()].concat();
    let bytes = state
        .get(&key)
        .expect("state get should not fail")
        .expect("session state should exist");
    codec::from_bytes_canonical(&bytes).expect("agent state should decode")
}

fn seed_resolved_intent(
    state: &mut IAVLTree<HashCommitmentScheme>,
    session_id: [u8; 32],
    scope: IntentScopeProfile,
) {
    let key = [b"agent::state::".as_slice(), session_id.as_slice()].concat();
    let bytes = state
        .get(&key)
        .expect("state get should not fail")
        .expect("session state should exist");
    let mut agent_state: AgentState =
        codec::from_bytes_canonical(&bytes).expect("agent state should decode");
    let required_capabilities = match scope {
        IntentScopeProfile::WebResearch => vec![
            CapabilityId::from("web.retrieve"),
            CapabilityId::from("browser.interact"),
            CapabilityId::from("browser.inspect"),
            CapabilityId::from("conversation.reply"),
        ],
        IntentScopeProfile::UiInteraction => vec![
            CapabilityId::from("ui.interact"),
            CapabilityId::from("ui.inspect"),
            CapabilityId::from("conversation.reply"),
        ],
        _ => vec![CapabilityId::from("conversation.reply")],
    };
    agent_state.resolved_intent = Some(ResolvedIntentState {
        intent_id: match scope {
            IntentScopeProfile::WebResearch => "web.research".to_string(),
            IntentScopeProfile::UiInteraction => "ui.interaction".to_string(),
            _ => "unknown".to_string(),
        },
        scope,
        band: IntentConfidenceBand::High,
        score: 0.99,
        top_k: vec![],
        required_capabilities,
        required_evidence: vec![],
        success_conditions: vec![],
        risk_class: "low".to_string(),
        preferred_tier: match scope {
            IntentScopeProfile::UiInteraction => "visual_last".to_string(),
            _ => "tool_first".to_string(),
        },
        intent_catalog_version: "test".to_string(),
        embedding_model_id: "test".to_string(),
        embedding_model_version: "test".to_string(),
        similarity_function_id: "cosine".to_string(),
        intent_set_hash: [0u8; 32],
        tool_registry_hash: [0u8; 32],
        capability_ontology_hash: [0u8; 32],
        query_normalization_version: "test".to_string(),
        intent_catalog_source_hash: [0u8; 32],
        evidence_requirements_hash: [0u8; 32],
        provider_selection: None,
        instruction_contract: None,
        constrained: false,
    });
    agent_state.awaiting_intent_clarification = false;
    agent_state.status = AgentStatus::Running;
    agent_state.current_tier = match scope {
        IntentScopeProfile::UiInteraction => ExecutionTier::VisualForeground,
        _ => ExecutionTier::DomHeadless,
    };
    state
        .insert(
            &key,
            &codec::to_bytes_canonical(&agent_state).expect("state encode"),
        )
        .expect("state insert should not fail");
}

fn apply_test_policy(
    state: &mut IAVLTree<HashCommitmentScheme>,
    session_id: [u8; 32],
    allow_all: bool,
) {
    let mut rules = default_safe_policy();
    rules.ontology_policy.intent_routing.shadow_mode = true;
    if allow_all {
        rules.defaults = DefaultPolicy::AllowAll;
    }
    let policy_key = [AGENT_POLICY_PREFIX, session_id.as_slice()].concat();
    state
        .insert(
            &policy_key,
            &codec::to_bytes_canonical(&rules).expect("policy encode"),
        )
        .expect("policy insert should not fail");
}

fn build_memory_runtime() -> Result<Arc<MemoryRuntime>> {
    Ok(Arc::new(MemoryRuntime::open_sqlite_in_memory()?))
}

async fn run_agent_self_healing_journey() -> Result<()> {
    build_test_artifacts();

    let gui = Arc::new(MockGuiDriver {
        fail_count: Arc::new(Mutex::new(0)),
    });
    let brain = Arc::new(ResilientBrain);
    let memory_runtime = build_memory_runtime()?;

    let service = RuntimeAgentService::new_hybrid(
        gui,
        Arc::new(TerminalDriver::new()),
        Arc::new(BrowserDriver::new()),
        brain.clone(),
        brain.clone(),
    )
    .with_memory_runtime(memory_runtime);
    let mut state = IAVLTree::new(HashCommitmentScheme::new());
    let services_dir = ServiceDirectory::new(vec![]);
    let mut ctx = build_ctx(&services_dir);

    let session_id = [1u8; 32];
    let start_params = StartAgentParams {
        session_id,
        goal: "Click".into(),
        runtime_route_frame: None,
        max_steps: 5,
        parent_session_id: None,
        initial_budget: 1000,
        mode: AgentMode::Agent,
    };
    service
        .handle_service_call(
            &mut state,
            "start@v1",
            &codec::to_bytes_canonical(&start_params).unwrap(),
            &mut ctx,
        )
        .await?;
    apply_test_policy(&mut state, session_id, true);
    seed_resolved_intent(&mut state, session_id, IntentScopeProfile::UiInteraction);

    let step_params = StepAgentParams { session_id };
    let step_bytes = codec::to_bytes_canonical(&step_params).unwrap();

    for _ in 0..3 {
        service
            .handle_service_call(&mut state, "step@v1", &step_bytes, &mut ctx)
            .await?;
    }

    let final_state = read_agent_state(&state, session_id);
    assert!(final_state.step_count >= 1);
    assert!(
        !matches!(final_state.status, AgentStatus::Failed(_)),
        "agent should not hard-fail in resilience validation path"
    );

    Ok(())
}

#[test]
fn test_agent_self_healing() -> Result<()> {
    run_agent_resilience_test(run_agent_self_healing_journey)
}

#[tokio::test(flavor = "multi_thread")]
async fn latest_news_timeout_fails_fast_without_remedy_churn() -> Result<()> {
    build_test_artifacts();

    let _lock = WEB_ENV_LOCK
        .get_or_init(|| Mutex::new(()))
        .lock()
        .expect("env lock");
    let _force_browser_timeout = ScopedEnvVar::set("IOI_WEB_TEST_FORCE_BROWSER_TIMEOUT", "1");
    let _force_http_timeout = ScopedEnvVar::set("IOI_WEB_TEST_FORCE_HTTP_TIMEOUT", "1");

    let (event_tx, mut event_rx) = broadcast::channel(256);
    let gui = Arc::new(MockGuiDriver {
        fail_count: Arc::new(Mutex::new(0)),
    });
    let brain = Arc::new(WebTimeoutBrain);
    let memory_runtime = build_memory_runtime()?;

    let service = RuntimeAgentService::new_hybrid(
        gui,
        Arc::new(TerminalDriver::new()),
        Arc::new(BrowserDriver::new()),
        brain.clone(),
        brain.clone(),
    )
    .with_memory_runtime(memory_runtime)
    .with_event_sender(event_tx);

    let mut state = IAVLTree::new(HashCommitmentScheme::new());
    let services_dir = ServiceDirectory::new(vec![]);
    let mut ctx = build_ctx(&services_dir);
    let session_id = [9u8; 32];

    let start_params = StartAgentParams {
        session_id,
        goal: "search latest news and summarize".into(),
        runtime_route_frame: None,
        max_steps: 12,
        parent_session_id: None,
        initial_budget: 1000,
        mode: AgentMode::Agent,
    };
    service
        .handle_service_call(
            &mut state,
            "start@v1",
            &codec::to_bytes_canonical(&start_params).unwrap(),
            &mut ctx,
        )
        .await?;
    apply_test_policy(&mut state, session_id, false);
    seed_resolved_intent(&mut state, session_id, IntentScopeProfile::WebResearch);

    let started = Instant::now();
    for _ in 0..8 {
        let mut final_state = read_agent_state(&state, session_id);
        if matches!(final_state.status, AgentStatus::Completed(_)) {
            break;
        }
        if matches!(final_state.status, AgentStatus::Failed(_)) {
            break;
        }
        if matches!(final_state.status, AgentStatus::Paused(_)) {
            let clarify = PostMessageParams {
                session_id,
                role: "user".to_string(),
                content: "search latest news and summarize".to_string(),
            };
            service
                .handle_service_call(
                    &mut state,
                    "post_message@v1",
                    &codec::to_bytes_canonical(&clarify).unwrap(),
                    &mut ctx,
                )
                .await?;
            final_state = read_agent_state(&state, session_id);
            if !matches!(final_state.status, AgentStatus::Running) {
                continue;
            }
        }
        if !matches!(final_state.status, AgentStatus::Running) {
            break;
        }

        service
            .handle_service_call(
                &mut state,
                "step@v1",
                &codec::to_bytes_canonical(&StepAgentParams { session_id }).unwrap(),
                &mut ctx,
            )
            .await?;
    }
    let elapsed = started.elapsed();
    assert!(
        elapsed.as_secs() <= 60,
        "timeout path should terminate within 60s, got {:?}",
        elapsed
    );

    let final_state = read_agent_state(&state, session_id);
    assert!(final_state.step_count <= 8);

    let mut saw_filesystem_list_directory = false;
    let mut saw_max_steps = false;
    let mut saw_unknown_custom_tool = false;

    while let Ok(event) = event_rx.try_recv() {
        match event {
            KernelEvent::RoutingReceipt(receipt) => {
                if receipt.tool_name == "file__list" {
                    saw_filesystem_list_directory = true;
                }
                if receipt.tool_name.contains("Custom(\"unknown\")")
                    || receipt.tool_name.contains("custom(\"unknown\")")
                {
                    saw_unknown_custom_tool = true;
                }
            }
            KernelEvent::AgentActionResult { tool_name, .. } => {
                if tool_name == "file__list" {
                    saw_filesystem_list_directory = true;
                }
                if tool_name == "system::max_steps_reached" {
                    saw_max_steps = true;
                }
            }
            _ => {}
        }
    }

    assert!(
        !saw_filesystem_list_directory,
        "unexpected filesystem remediation churn observed"
    );
    assert!(
        !saw_unknown_custom_tool,
        "routing should not emit Custom(\"unknown\") tool targets"
    );
    assert!(
        !saw_max_steps,
        "timeout scenario should not terminate via max-steps budget"
    );

    Ok(())
}
